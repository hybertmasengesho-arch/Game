import * as THREE from 'three';
import { bake, mergeColored, clamp, wrapPi, rand, resolveCircle } from './utils.js';
import { buildSoldierGeos } from './soldier_geo.js';
import { Brain } from './ai.js';
import { makeExt } from './ext_soldier.js';


export const SOLDIER_TYPES = {
  rifleman: { name: 'RIFLEMAN', hp: 100, speed: 2.1, scale: 1.0, burst: 3, gap: [1.2, 2.2], rate: .12, aim: .026, dmg: [2, 4], range: [14, 26], head: 0x8a6a52,
    cloth: 0x4b5a3a, cloth2: 0x3a4630, cloth3: 0x6b6a4a, vest: 0x2b2f2a, plate: 0x3c4238, helmet: 0x3b4632, mask: 0x1c1c1c, boot: 0x2a221c, glove: 0x202020, gun: 'rifle' },
  heavy: { name: 'HEAVY', hp: 240, speed: 1.35, scale: 1.12, burst: 7, gap: [1.6, 2.8], rate: .1, aim: .04, dmg: [3, 5], range: [16, 28], head: 0x7b5b45, armor: .55,
    cloth: 0x30363a, cloth2: 0x252a2d, cloth3: 0x3a4044, vest: 0x1d2226, plate: 0x6d6049, helmet: 0x23282b, mask: 0x111111, boot: 0x1a1a1a, glove: 0x151515, gun: 'lmg' },
  runner: { name: 'RUNNER', hp: 70, speed: 3.3, scale: .97, burst: 3, gap: [.7, 1.4], rate: .085, aim: .05, dmg: [2, 3], range: [8, 15], head: 0x9a765d,
    cloth: 0x7a6a4b, cloth2: 0x655838, cloth3: 0x8c7a58, vest: 0x4a4332, plate: 0x59503a, helmet: 0x7a2b22, mask: 0x2a2018, boot: 0x3a2a1c, glove: 0x302618, gun: 'smg' },
};

const geoCache = {};
function buildGeos(typeKey) { if (!geoCache[typeKey]) geoCache[typeKey] = { hi: buildSoldierGeos(typeKey, SOLDIER_TYPES[typeKey], 0), lo: buildSoldierGeos(typeKey, SOLDIER_TYPES[typeKey], 1) }; return geoCache[typeKey]; }

const _v = new THREE.Vector3(), _fl = new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: .95, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
const flashGeo = (() => { const a = new THREE.PlaneGeometry(.34, .16), b = a.clone().rotateZ(Math.PI / 2), c = new THREE.PlaneGeometry(.2, .2); return mergeColored([bake(a, 0xffffff, [0, 0, .12], [0, Math.PI / 2, 0]), bake(b, 0xffffff, [0, 0, .12], [0, Math.PI / 2, 0]), bake(c, 0xffffff, [0, 0, .06])]); })();
export const flashMat = _fl;

export class Soldier {
  constructor(typeKey, scene, x, z, o = {}) {
    this.typeKey = typeKey; this.T = SOLDIER_TYPES[typeKey]; const G = buildGeos(typeKey);
    this.squad = o.squad ?? -1;
    this.mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .85, metalness: .05, emissive: 0xff2200, emissiveIntensity: 0 });
    this.root = new THREE.Group(); this.root.position.set(x, 0, z); this.root.rotation.y = Math.random() * 6.28; this.root.scale.setScalar(this.T.scale); scene.add(this.root);
    this.pelvis = new THREE.Group(); this.pelvis.position.y = .97; this.root.add(this.pelvis);
    this.meshes = [];
    this.meshes = []; this.loMeshes = [];
    const mk = (geo, parent, part, lo) => { const m = new THREE.Mesh(geo, this.mat); m.castShadow = !lo; m.visible = !lo; m.userData = { enemy: this, part }; parent.add(m); (lo ? this.loMeshes : this.meshes).push(m); return m; };
    this.upper = new THREE.Group(); this.pelvis.add(this.upper); this.neck = new THREE.Group(); this.neck.position.y = .68; this.upper.add(this.neck);
    this.legs = [-1, 1].map(s => { const t = new THREE.Group(); t.position.set(s * .1, -.02, 0); this.pelvis.add(t); const sh = new THREE.Group(); sh.position.y = -.45; t.add(sh); return { t, sh }; });
    for (const lo of [false, true]) { const g = lo ? G.lo : G.hi; mk(g.upper, this.upper, 'body', lo); mk(g.head, this.neck, 'head', lo); this.legs.forEach(l => { mk(g.thigh, l.t, 'body', lo); mk(g.shin, l.sh, 'body', lo); }); }
    this.lod = 0;
    this.flash = new THREE.Mesh(flashGeo, _fl); this.flash.position.set(-.02, .52, G.hi.muz + .02); this.flash.visible = false; this.upper.add(this.flash);
    this.hp = this.T.hp; this.alive = true; this.deadT = 0; this.phase = Math.random(); this.flashT = 0; this.hitT = 0; this.kick = 0;
    this.vx = 0; this.vz = 0; this.moveSpd = 0; this.fdot = 1; this.headYaw = 0; this.deathYaw = 0; this.deathSide = Math.random() < .5 ? 1 : -1;
    this.prefer = rand(this.T.range[0], this.T.range[1]); this.alert = false;
    this.brain = new Brain(this, o.dir, o.patrol);
    this.ext = makeExt(this, this.T, typeKey);
    if (this.ext) { for (const m of this.meshes.concat(this.loMeshes)) m.visible = false; this.pelvis.visible = false; this.ext.rifle.add(this.flash); this.flash.position.set(0, .075, G.hi.muz - .1); this.flash.scale.setScalar(1); }
  }
  get state() { return this.brain.state; }
  get hitMeshes() { return this.ext ? this.ext.curMeshes() : (this.lod ? this.loMeshes : this.meshes); }
  setLod(l) { if (this.ext) { this.lod = l; this.ext.setLod(l); return; } if (l === this.lod) return; this.lod = l; for (const m of this.meshes) m.visible = !l; for (const m of this.loMeshes) m.visible = !!l; }
  dispose(scene) { this.brain.releaseCover(); scene.remove(this.root); this.mat.dispose(); }
  muzzle(out) { this.flash.updateWorldMatrix(true, false); return this.flash.getWorldPosition(out); }
  hit(dmg, head, from) {
    if (!this.alive) return false;
    this.hp -= (head ? dmg * 3 : dmg * (this.T.armor || 1)); this.hitT = .12; this.kick = .6;
    if (this.hp <= 0) { this.alive = false; this.deadT = 0; this.flash.visible = false; this.brain.releaseCover(); return true; }
    if (from) this.brain.onHit(from.x, from.z); return false;
  }
  /** returns an action {fire, suppress, spread, tx, tz} or null */
  update(dt, ctx) {
    this.mat.emissiveIntensity = this.hitT > 0 ? .9 : 0; if (this.ext) this.ext.flash(this.hitT > 0 ? .8 : 0); if (this.hitT > 0) this.hitT -= dt;
    if (this.flashT > 0) { this.flashT -= dt; if (this.flashT <= 0) this.flash.visible = false; }
    const r = this.root;
    if (!this.alive) {
      this.deadT += dt; if (this.ext) { this.ext.die(this.deadT); return null; } const k = Math.min(1, this.deadT / .6), e = 1 - (1 - k) * (1 - k);
      this.pelvis.rotation.set(-e * 1.45, 0, e * .35 * this.deathSide); r.position.y = -e * .12; this.pelvis.position.y = .97 - e * .55;
      for (const l of this.legs) { l.t.rotation.x = e * .3; l.sh.rotation.x = e * .6; } this.neck.rotation.set(e * .3, 0, 0);
      return null;
    }
    this.alert = this.brain.state === 'combat' || this.brain.state === 'invest';
    { const dd = Math.hypot(ctx.player.x - r.position.x, ctx.player.z - r.position.z); this.setLod(dd > 34 ? 1 : 0); for (const m of this.meshes) m.castShadow = dd < 28; if (this.ext) this.ext.setShadow(dd < 28); }
    const act = this.brain.update(dt, ctx);
    // ---- movement: accelerate toward desired velocity, then collide ----
    const acc = 16; this.vx += clamp(act.vx - this.vx, -acc * dt, acc * dt); this.vz += clamp(act.vz - this.vz, -acc * dt, acc * dt);
    // separation from squad mates
    for (const o of ctx.soldiers) if (o !== this && o.alive) { const ddx = r.position.x - o.root.position.x, ddz = r.position.z - o.root.position.z, d = Math.hypot(ddx, ddz); if (d < 1.3 && d > 1e-3) { this.vx += ddx / d * (1.3 - d) * 6 * dt * 4; this.vz += ddz / d * (1.3 - d) * 6 * dt * 4; } }
    const ox = r.position.x, oz = r.position.z; let nx = ox + this.vx * dt, nz = oz + this.vz * dt;
    const o = resolveCircle(nx, nz, .42, ctx.world.colliders, 0); nx = o.x; nz = o.z;
    for (const v of ctx.vehicles) for (const [qx, qz, qr] of v.circles()) { const ddx = nx - qx, ddz = nz - qz, d = Math.hypot(ddx, ddz), m = qr + .4; if (d < m && d > 1e-4) { nx = qx + ddx / d * m; nz = qz + ddz / d * m; } }
    r.position.x = clamp(nx, -ctx.half + 2, ctx.half - 2); r.position.z = clamp(nz, -ctx.half + 2, ctx.half - 2);
    const spdNow = Math.hypot(r.position.x - ox, r.position.z - oz) / Math.max(dt, 1e-3); this.moveSpd += (spdNow - this.moveSpd) * Math.min(1, 10 * dt);
    // ---- facing ----
    let want = act.face; if (want === null || want === undefined) { want = this.moveSpd > .3 ? Math.atan2(this.vx, this.vz) : r.rotation.y; }
    r.rotation.y += wrapPi(want - r.rotation.y) * Math.min(1, (act.face !== null && act.face !== undefined ? 9 : 7) * dt);
    const mvAng = Math.atan2(this.vx, this.vz), fd = Math.cos(wrapPi(mvAng - r.rotation.y)); this.fdot += (fd - this.fdot) * Math.min(1, 8 * dt);
    if (this.ext) { this.ext.update(dt, this.moveSpd); if (act.fire) { this.flash.visible = true; this.flashT = .05; this.flash.rotation.z = Math.random() * 3; this.ext.kick(); } return act.fire ? act : null; }
    // ---- walk animation ----
    const sgn = this.fdot >= -.2 ? 1 : -1; this.phase += dt * this.moveSpd / 1.45 * sgn;
    const w = Math.min(1, this.moveSpd / 1.6), run = clamp((this.moveSpd - 2.2) / 1.5, 0, 1), s = Math.sin(this.phase * Math.PI * 2);
    this.legs.forEach((l, i) => { const p = Math.sin(this.phase * Math.PI * 2 + i * Math.PI); l.t.rotation.x = -p * (.62 + .25 * run) * w; l.sh.rotation.x = Math.max(0, Math.sin(this.phase * Math.PI * 2 + i * Math.PI - 1.2)) * (.95 + .5 * run) * w; });
    this.pelvis.position.y = .97 - Math.abs(s) * (.03 + .03 * run) * w - .03 * run * w + Math.sin(ctx.time * 1.5 + this.phase) * .004;
    this.pelvis.rotation.set((.04 + .16 * run) * w, 0, Math.sin(this.phase * Math.PI * 2) * .035 * w);
    this.upper.rotation.set(0, Math.sin(this.phase * Math.PI * 2) * .06 * w, 0);
    // head tracks the player when alert, scans when patrolling
    const toP = wrapPi(Math.atan2(ctx.player.x - r.position.x, ctx.player.z - r.position.z) - r.rotation.y), hy = this.alert ? clamp(toP, -1, 1) : Math.sin(ctx.time * .6 + this.phase * 5) * .35;
    this.headYaw += (hy - this.headYaw) * Math.min(1, 8 * dt); this.neck.rotation.y = this.headYaw;
    if (this.kick > 0) { this.kick = Math.max(0, this.kick - dt * 5); this.upper.rotation.x -= this.kick * .2; this.upper.position.z = -this.kick * .05; } else this.upper.position.z = 0;
    if (act.fire) { this.flash.visible = true; this.flashT = .05; this.flash.rotation.z = Math.random() * 3; this.upper.rotation.x -= .05; }
    return act.fire ? act : null;
  }
}
