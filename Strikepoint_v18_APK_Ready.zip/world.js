import * as THREE from 'three';
import { bake, mergeColored, roundBox, capsuleGeo, limb, noise3 } from './utils.js';

export const HALF = 110;   // arena half-size in metres (v13: 220 x 220 m)
function canvasTex(w, h, fn, rep) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (rep) t.repeat.set(rep, rep); t.anisotropy = 4; return t;
}
const noise = (x, w, h, n, a, cols) => { for (let i = 0; i < n; i++) { x.fillStyle = cols[i % cols.length].replace('A', (Math.random() * a).toFixed(3)); x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 3, 1 + Math.random() * 3); } };
const BX = new THREE.BoxGeometry(1, 1, 1), SPH = new THREE.SphereGeometry(1, 7, 5), ICO = new THREE.IcosahedronGeometry(1, 1), CYL = (r0, r1, h, s = 14) => new THREE.CylinderGeometry(r0, r1, h, s);
const shade = (hex, jit = .1) => { const c = new THREE.Color(hex); return (x, y, z, nx, ny) => { const k = (.8 + .2 * (ny * .5 + .5)) * (1 - jit + jit * 2 * noise3(x * 3, y * 3, z * 3)); return [c.r * k, c.g * k, c.b * k]; }; };
let seed = 12345; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

export function buildWorld(scene) {
  const colliders = [], CELL = 24, chunks = new Map();
  const put = (kind, g) => { g.computeBoundingBox(); const c = g.boundingBox.getCenter(new THREE.Vector3()), key = kind + '|' + Math.floor(c.x / CELL) + ',' + Math.floor(c.z / CELL); let a = chunks.get(key); if (!a) { a = []; chunks.set(key, a); } a.push(g); };
  const P = { push: g => put('props', g) };
  const sandTex = canvasTex(256, 256, (x, w, h) => { x.fillStyle = '#9b8c70'; x.fillRect(0, 0, w, h); noise(x, w, h, 5000, .35, ['rgba(120,104,78,A)', 'rgba(190,172,140,A)', 'rgba(90,78,58,A)']); for (let i = 0; i < 24; i++) { x.fillStyle = 'rgba(80,66,44,.06)'; x.beginPath(); x.ellipse(Math.random() * w, Math.random() * h, 20 + Math.random() * 40, 8 + Math.random() * 16, Math.random() * 3, 0, 7); x.fill(); } }, 80);
  const asphaltTex = canvasTex(256, 256, (x, w, h) => { x.fillStyle = '#3b3f42'; x.fillRect(0, 0, w, h); noise(x, w, h, 6000, .5, ['rgba(20,22,24,A)', 'rgba(90,94,98,A)', 'rgba(60,64,68,A)']); x.strokeStyle = 'rgba(15,15,15,.5)'; for (let i = 0; i < 5; i++) { x.beginPath(); x.moveTo(Math.random() * w, Math.random() * h); for (let j = 0; j < 6; j++) x.lineTo(Math.random() * w, Math.random() * h); x.stroke(); } }, 1);
  const concTex = canvasTex(128, 128, (x, w, h) => { x.fillStyle = '#858b88'; x.fillRect(0, 0, w, h); noise(x, w, h, 1500, .25, ['rgba(60,66,62,A)', 'rgba(170,176,172,A)']); x.fillStyle = 'rgba(40,44,42,.1)'; for (let i = 0; i < 4; i++) x.fillRect(0, i * 32, w, 1); });
  const mats = {
    sand: new THREE.MeshStandardMaterial({ map: sandTex, bumpMap: sandTex, bumpScale: 1.2, roughness: 1 }), asphalt: new THREE.MeshStandardMaterial({ map: asphaltTex, bumpMap: asphaltTex, bumpScale: 1.5, roughness: .93 }),
    concrete: new THREE.MeshStandardMaterial({ map: concTex, bumpMap: concTex, bumpScale: 1.4, roughness: .95 }), crate: new THREE.MeshStandardMaterial({ color: 0x76654a, roughness: 1 }),
    props: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .86, metalness: .08 }),
  };
  function plainBox(kind, x, y, z, sx, sy, sz) {
    const g = new THREE.BoxGeometry(sx, sy, sz), uv = g.attributes.uv, n = g.attributes.normal;
    for (let i = 0; i < uv.count; i++) { const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)); const su = ax > .5 ? sz : sx, sv = ax > .5 ? sy : ay > .5 ? sz : sy; uv.setXY(i, uv.getX(i) * su / 4, uv.getY(i) * sv / 4); }
    g.translate(x, y, z); put(kind, g.toNonIndexed());
  }
  const solid = (x, z, w, d, h, y0 = 0) => colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2, minY: y0, h });
  const sbox = (kind, x, y, z, sx, sy, sz) => { plainBox(kind, x, y, z, sx, sy, sz); solid(x, z, sx, sz, y + sy / 2, y - sy / 2); };
  const pb = (c, p, s, r) => P.push(bake(BX, c, p, r || [0, 0, 0], s));
  const pr = (c, p, w, h, d, rad, r) => P.push(bake(roundBox(w, h, d, rad, 2), c, p, r || [0, 0, 0]));
  const pe = (c, p, s, r) => P.push(bake(SPH, c, p, r || [0, 0, 0], s));
  const pc = (c, p, r0, r1, h, rot, seg = 14) => P.push(bake(CYL(r0, r1, h, seg), c, p, rot || [0, 0, 0]));
  const inRoad = (x, z, m = 0) => (Math.abs(x) < 6 + m) || (Math.abs(z) < 6 + m) || (Math.abs(Math.abs(x) - 40) < 5 + m) || (Math.abs(z + 45) < 5 + m && Math.abs(x) < 44) || (z > 50 - m && Math.abs(x) < 22 + m)
    || (Math.abs(Math.abs(x) - 98) < 4 + m && Math.abs(z) < 102) || (Math.abs(Math.abs(z) - 98) < 4 + m && Math.abs(x) < 102);   // outer ring road

  // ---------------- ground + road network ----------------
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), mats.sand); floor.rotation.x = -Math.PI / 2; floor.position.y = -.06; floor.receiveShadow = true; scene.add(floor);
  const roadPlane = (cx, cz, w, d, y) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mats.asphalt.clone()); m.material.map = mats.asphalt.map.clone(); m.material.map.needsUpdate = true; m.material.map.repeat.set(w / 8, d / 8); m.material.bumpMap = m.material.map; m.rotation.x = -Math.PI / 2; m.position.set(cx, y, cz); m.receiveShadow = true; scene.add(m); };
  roadPlane(0, 11, 8, 114, .010); roadPlane(0, 0, 136, 8, .011); roadPlane(0, 60, 44, 16, .012);
  roadPlane(-40, -4, 6, 112, .009); roadPlane(40, -4, 6, 112, .009); roadPlane(0, -45, 86, 6, .0095); roadPlane(0, -60, 8, 18, .0105);
  const dash = (x, z, alongZ) => pb(0xd9b640, [x, .02, z], alongZ ? [.14, .01, 2.2] : [2.2, .01, .14]);
  for (let z = -56; z < 52; z += 5) if (Math.abs(z) > 5) dash(0, z, true);
  for (let x = -66; x < 67; x += 5) if (Math.abs(x) > 5) dash(x, 0, false);
  for (let z = -56; z < 50; z += 5) { if (Math.abs(z + 45) > 4) { dash(-40, z, true); dash(40, z, true); } }
  for (let x = -38; x < 39; x += 5) if (Math.abs(x) > 5) dash(x, -45, false);
  for (let i = -8; i <= 8; i += 3) pb(0xd8d6cc, [i * 2.4, .02, 59], [.1, .01, 5.6]);            // parking bays
  for (let k = -3; k <= 3; k++) { pb(0xdadad2, [k * .9 - .4, .02, 6.5], [.5, .01, 3]); pb(0xdadad2, [k * .9 - .4, .02, -6.5], [.5, .01, 3]); }   // crosswalks
  for (let i = 0; i < 40; i++) { const x = (rnd() - .5) * 130, z = (rnd() - .5) * 130; const d = new THREE.Mesh(new THREE.CircleGeometry(.5 + rnd() * 1.1, 12), new THREE.MeshStandardMaterial({ color: 0x24282a, roughness: 1 })); d.rotation.x = -Math.PI / 2; d.position.set(x, .016, z); scene.add(d); }
  // ---------------- monument / roundabout island ----------------
  pc(0x7b8078, [0, .2, 0], 3.2, 3.4, .4, [0, 0, 0], 24); pc(0x959a92, [0, .55, 0], 2.2, 2.4, .5, [0, 0, 0], 24); pb(0x8d9289, [0, 1.6, 0], [1.4, 1.7, 1.4]); P.push(bake(new THREE.CylinderGeometry(.12, .45, 4.5, 4), 0xb9bdb4, [0, 4.4, 0], [0, .785, 0])); pe(0xd6b24a, [0, 6.9, 0], [.28, .28, .28]);
  solid(0, 0, 4.4, 4.4, 6.2);
  // ---------------- perimeter walls ----------------
  const W = HALF;
  sbox('concrete', 0, 2, -W, 2 * W, 4, 1.2); sbox('concrete', 0, 2, W, 2 * W, 4, 1.2); sbox('concrete', -W, 2, 0, 1.2, 4, 2 * W); sbox('concrete', W, 2, 0, 1.2, 4, 2 * W);
  for (let i = -W; i <= W; i += 7) { pb(0x777d7a, [i, 2.1, -W + .65], [.9, 4.3, .5]); pb(0x777d7a, [i, 2.1, W - .65], [.9, 4.3, .5]); pb(0x777d7a, [-W + .65, 2.1, i], [.5, 4.3, .9]); pb(0x777d7a, [W - .65, 2.1, i], [.5, 4.3, .9]); }
  for (const z of [-W + .7, W - .7]) pc(0x2a2d2e, [0, 4.35, z], .09, .09, 2 * W, [0, 0, Math.PI / 2], 6);
  for (const x of [-W + .7, W - .7]) pc(0x2a2d2e, [x, 4.35, 0], .09, .09, 2 * W, [Math.PI / 2, 0, 0], 6);
  // ---------------- buildings ----------------
  function building(x, z, w, h, d, face = 1) {
    sbox('concrete', x, h / 2, z, w, h, d);
    pb(0x4a4f4d, [x, .35, z], [w + .15, .7, d + .15]);
    pb(0x6f7471, [x, h + .12, z - d / 2 + .15], [w + .3, .55, .3]); pb(0x6f7471, [x, h + .12, z + d / 2 - .15], [w + .3, .55, .3]); pb(0x6f7471, [x - w / 2 + .15, h + .12, z], [.3, .55, d]); pb(0x6f7471, [x + w / 2 - .15, h + .12, z], [.3, .55, d]);
    for (const s of [-1, 1]) for (const e of [-1, 1]) pb(0x676c69, [x + s * w / 2, h / 2, z + e * d / 2], [.5, h + .2, .5]);
    const rows = h > 4.5 ? 2 : 1;
    for (let r = 0; r < rows; r++) {
      const wy = rows === 2 ? 1.8 + r * 2.4 : h * .6;
      for (const side of [1, -1]) for (let xx = x - w / 2 + 1.6; xx < x + w / 2 - 1; xx += 2.6) {
        if (side === face && r === 0 && Math.abs(xx - x) < 1.1) continue; const zz = z + side * (d / 2 + .02);
        pb(0x1b2328, [xx, wy, zz + side * .02], [.95, 1.1, .06]); pb(0x5a5f5c, [xx, wy + .62, zz + side * .05], [1.15, .1, .12]); pb(0x5a5f5c, [xx, wy - .62, zz + side * .09], [1.2, .09, .2]); 
      }
      for (const side of [1, -1]) for (let zz = z - d / 2 + 1.6; zz < z + d / 2 - 1; zz += 2.8) { const xx = x + side * (w / 2 + .02); pb(0x1b2328, [xx + side * .02, wy, zz], [.06, 1.1, .95]); pb(0x5a5f5c, [xx + side * .09, wy - .62, zz], [.2, .09, 1.2]); }
    }
    const dz = z + face * (d / 2); pb(0x2d3330, [x, 1.1, dz + face * .04], [1.3, 2.2, .1]); pb(0x55605a, [x, 1.1, dz + face * .1], [1.0, 2.0, .06]); pb(0x4a4f4d, [x, .1, dz + face * .6], [1.8, .2, 1.1]); pb(0x3b4a3a, [x, 2.5, dz + face * .6], [2.2, .08, 1.2], [face * .12, 0, 0]);
    pc(0x6a6f6c, [x - w / 4, h + .55, z], .5, .5, .7, [0, 0, 0], 12); pr(0x8a8f8c, [x + w / 4, h + .55, z + d / 4], 1.2, .7, .9, .06); pr(0x2e3234, [x + w / 4, h + .55, z + d / 4 + .46], .9, .4, .04, .01);
    pc(0x7b3b2b, [x + w / 4 - 1.6, h + 1.45, z - d / 4], .6, .6, 1.2, [0, 0, 0]); for (const a of [-.4, .4]) for (const b of [-.4, .4]) pb(0x3a3f43, [x + w / 4 - 1.6 + a, h + .65, z - d / 4 + b], [.08, .9, .08]);
    P.push(limb([x - w / 3, h + .3, z - d / 3], [x - w / 3, h + 3.2, z - d / 3], .03, .02, 0x333333, 6)); pb(0x6a6f6c, [x - w / 2 + 1.2, h + .6, z + d / 4], [.9, 1, .9]);
  }
  const B = [[14, -14, 10, 5, 8, 1], [27, -15, 12, 6.2, 9, 1], [13, -30, 9, 4, 10, 1], [28, -32, 11, 5, 9, 1], [14, 17, 9, 4, 10, -1], [28, 19, 10, 5, 9, -1], [15, 36, 12, 6.2, 9, -1], [30, 38, 10, 5, 8, -1],
    [52, -16, 10, 5, 9, 1], [58, -34, 12, 6.2, 9, 1], [54, 14, 10, 5, 9, -1], [58, 36, 9, 4, 10, -1],
    [-22, -16, 20, 6, 12, 1], [-24, -34, 18, 5.5, 10, 1], [-54, -18, 18, 7, 12, 1], [-56, -36, 14, 5, 10, 1], [-22, 18, 16, 5, 12, -1], [-24, 38, 14, 4.5, 10, -1], [-54, 16, 14, 5, 10, -1], [-58, 34, 12, 5, 9, -1],
    [0, -62, 16, 6, 9, 1], [-17, -58, 8, 4, 8, 1], [17, -58, 8, 4, 8, 1]];
  B.forEach(b => building(...b));
  // ---------------- HQ compound walls + gate + watch towers ----------------
  for (const s of [-1, 1]) { sbox('concrete', s * 15, 1.6, -52, 22, 3.2, .8); sbox('concrete', s * 26, 1.6, -60, .8, 3.2, 16); pb(0x2a2d2e, [s * 15, 3.4, -52], [22, .15, .15]); }
  pb(0x6f7471, [-4.4, 2.2, -52], [.8, 4.4, 1]); pb(0x6f7471, [4.4, 2.2, -52], [.8, 4.4, 1]); pb(0x6f7471, [0, 4.5, -52], [9.6, .6, 1]);
  function tower(x, z) { for (const a of [-1, 1]) for (const b of [-1, 1]) { pb(0x4a4f4d, [x + a * 1.2, 2.6, z + b * 1.2], [.3, 5.2, .3]); solid(x + a * 1.2, z + b * 1.2, .35, .35, 5.2); } pb(0x555a57, [x, 5.35, z], [3.2, .25, 3.2]); for (const a of [-1, 1]) { pb(0x6f7471, [x + a * 1.55, 5.95, z], [.1, 1.1, 3.2]); pb(0x6f7471, [x, 5.95, z + a * 1.55], [3.2, 1.1, .1]); } pb(0x3b4a3a, [x, 7.1, z], [3.8, .15, 3.8]); for (const a of [-1, 1]) for (const b of [-1, 1]) pb(0x3a3f43, [x + a * 1.7, 6.5, z + b * 1.7], [.1, 1.2, .1]); pb(0x2a2d2e, [x, 5.9, z + 1.4], [.3, .25, .9]); }
  [[-24, -54], [24, -54], [-24, -66], [24, -66], [-60, 44], [60, 44]].forEach(t => tower(...t));
  // ---------------- crates, containers, barriers, sandbags, drums, tyres ----------------
  const crate = (x, z, w, h, d) => {
    sbox('crate', x, h / 2, z, w, h, d);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) pb(0x4a3e2a, [x + sx * (w / 2 - .06), h / 2, z + sz * (d / 2 - .06)], [.12, h + .02, .12]);
    for (const sy of [.06, h - .06]) { pb(0x4a3e2a, [x, sy, z + d / 2], [w + .02, .12, .03]); pb(0x4a3e2a, [x, sy, z - d / 2], [w + .02, .12, .03]); pb(0x4a3e2a, [x + w / 2, sy, z], [.03, .12, d + .02]); pb(0x4a3e2a, [x - w / 2, sy, z], [.03, .12, d + .02]); }
    pb(0x4a3e2a, [x, h / 2, z + d / 2 + .008], [w * .9, .08, .02], [0, 0, .72]);
  };
  const free = (x, z, r) => { if (inRoad(x, z, 1.5)) return false; if (Math.abs(x) > HALF - 4 || Math.abs(z) > HALF - 4) return false; for (const c of colliders) if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) return false; return true; };
  const crateLine = [[11.4, 6, 4, 8], [-12, 24, 3, 6]];
  for (const [x0, z0, n, dz] of [[-10, 52, 3, 0]]) { }
  for (let i = 0; i < 7; i++) { if (free(10, 10 + i * 2.5, 1)) crate(10, 10 + i * 2.5, 1.1, 1.4, 2.1); }    // crate wall near spawn side of town
  for (let i = 0; i < 46; i++) { const x = (rnd() - .5) * 128, z = (rnd() - .5) * 128; if (Math.hypot(x, z - 60) < 14 && z > 48) continue; if (free(x, z, 2)) { if (rnd() < .3) { crate(x, z, 1.4, 1.4, 1.4); crate(x + 1.5, z + .3, 1.2, 1.2, 1.2); if (rnd() < .5) { P.push(bake(BX, 0x4a3e2a, [x + .7, 1.7, z + .1], [0, .3, 0], [1.2, .02, 1.2])); } } else crate(x, z, 1.4, 1.4, 1.4); } }
  function container(x, z, alongX, color) {
    const L = 6, Wd = 2.4, H = 2.6, sx = alongX ? L : Wd, sz = alongX ? Wd : L;
    P.push(bake(roundBox(sx, H, sz, .05, 2), shade(color, .05), [x, H / 2 + .08, z])); solid(x, z, sx, sz, H + .08);
    for (let i = -L / 2 + .3; i < L / 2 - .2; i += .3) for (const s of [-1, 1]) pb(shade(color, .12), alongX ? [x + i, H / 2 + .08, z + s * (Wd / 2 + .02)] : [x + s * (Wd / 2 + .02), H / 2 + .08, z + i], alongX ? [.1, H - .2, .05] : [.05, H - .2, .1]);
    for (const e of [-1, 1]) pb(0x2a2d2e, alongX ? [x + e * (L / 2 + .02), H / 2 + .08, z] : [x, H / 2 + .08, z + e * (L / 2 + .02)], alongX ? [.06, H - .1, Wd - .1] : [Wd - .1, H - .1, .06]);
  }
  [[-60, -8, false, 0x7a2d22], [-60, -15, false, 0x2d4f7a], [-56, -48, true, 0x4a5a3a], [-47, -52, true, 0x7a6a2d], [60, -10, false, 0x2d4f7a], [60, -17, false, 0x7a2d22], [-60, 8, false, 0x4a5a3a], [62, 20, false, 0x7a6a2d], [-30, 52, true, 0x2d4f7a], [-30, 55, true, 0x7a2d22]].forEach(c => container(...c));
  const jersey = (() => { const s = new THREE.Shape(); s.moveTo(-.4, 0); s.lineTo(.4, 0); s.lineTo(.36, .3); s.lineTo(.17, .85); s.lineTo(.15, 1.3); s.lineTo(-.15, 1.3); s.lineTo(-.17, .85); s.lineTo(-.36, .3); s.closePath(); const g = new THREE.ExtrudeGeometry(s, { depth: 2.2, bevelEnabled: true, bevelSize: .03, bevelThickness: .03, bevelSegments: 2 }); g.translate(0, 0, -1.1); g.rotateY(Math.PI / 2); g.computeVertexNormals(); return g; })();
  const barrier = (x, z, i = 0) => { P.push(bake(jersey, shade(i % 2 ? 0x7d8380 : 0x8b908c, .08), [x, 0, z])); colliders.push({ minX: x - 1.15, maxX: x + 1.15, minZ: z - .4, maxZ: z + .4, minY: 0, h: 1.3 }); pb(i % 2 ? 0xb8452e : 0xe8e8e0, [x, .98, z + .42], [1.6, .12, .02]); };
  [[-3.3, -30], [-1, -30], [1.2, 20], [3.4, 20], [-8, -4.5], [-10.4, -4.5], [-13, -4.5], [8, 4.5], [10.4, 4.5], [13, 4.5]].forEach((b, i) => barrier(b[0], b[1], i));
  for (let i = -4; i < 4; i++) barrier(i * 2.4 - 8, -50 + 0, i);                                                          // HQ approach checkpoint (north road)
  const bag = capsuleGeo(.4, .17, .17, 10, 3, 1);
  function sandNest(x, z, alongX = true) {
    for (let i = 0; i < 6; i++) { const ox = alongX ? -2 + i * .8 : 0, oz = alongX ? 0 : -2 + i * .8; colliders.push({ minX: x + ox - (alongX ? .41 : .33), maxX: x + ox + (alongX ? .41 : .33), minZ: z + oz - (alongX ? .33 : .41), maxZ: z + oz + (alongX ? .33 : .41), minY: 0, h: .65 }); for (const [layer, off] of [[0, 0], [1, .4]]) P.push(bake(bag, shade(0xb09a6c, .12), alongX ? [x + ox + off - .4 * 0, .17 + layer * .28, z + oz] : [x + ox, .17 + layer * .28, z + oz + off], alongX ? [0, 0, Math.PI / 2] : [Math.PI / 2, 0, 0], [1, 1, .82])); }
  }
  [[-12, 12, true], [8, 28, true], [24, 3, true], [-30, 4, true], [30, -6, true], [-8, -52, true], [8, -52, true], [-18, -44, false], [48, -44, false], [-48, 30, true], [-30, 30, false]].forEach(n => sandNest(...n));
  const drumCols = [0x4a5a3a, 0x3a4f6a, 0x6a6a52];
  const drumGeo = (c, hazard) => { const L = [bake(CYL(.3, .3, .9, 12), shade(c, .08), [0, .45, 0])]; for (const y of [.25, .65]) L.push(bake(new THREE.TorusGeometry(.3, .015, 3, 10), 0x2a2d2e, [0, y, 0], [Math.PI / 2, 0, 0])); L.push(bake(CYL(.27, .27, .03, 10), 0x1b1d1e, [0, .91, 0])); if (hazard) { L.push(bake(CYL(.305, .305, .12, 12), 0xe8c020, [0, .45, 0])); L.push(bake(CYL(.31, .31, .03, 12), 0x111111, [0, .45, 0])); } return L; };
  for (let i = 0; i < 34; i++) { const x = (rnd() - .5) * 128, z = (rnd() - .5) * 128; if (!free(x, z, 1.2)) continue; const n = 1 + (rnd() * 3 | 0); for (let k = 0; k < n; k++) { const px = x + k * .7, pz = z + (k % 2) * .5, c = drumCols[(rnd() * 3) | 0]; for (const g of drumGeo(c, false)) { const q = g.clone(); q.translate(px, 0, pz); P.push(q); } colliders.push({ minX: px - .3, maxX: px + .3, minZ: pz - .3, maxZ: pz + .3, minY: 0, h: .9 }); } }
  // explosive barrels: red with hazard band, individually shootable
  const barrels = [];
  { const ex = [[-5, -49], [5, -49], [-14, -53], [14, -53], [12, -7], [24, -10], [-18, -7], [-30, -12], [30, 9], [44, -4], [-44, 6], [-9, 32], [10, 42], [-30, 38], [20, 30], [-12, -26], [34, -26], [50, 20], [-50, -30], [8, 10]];
    for (const [ox, oz] of ex) { let x = ox, z = oz, t = 0; while (!free(x, z, .8) && t++ < 30) { x = ox + (rnd() - .5) * 9; z = oz + (rnd() - .5) * 9; } if (t >= 30) continue;
      for (let k = 0; k < 2; k++) { const px = x + k * .75, pz = z, mesh = new THREE.Mesh(mergeColored(drumGeo(0xa8321f, true)), mats.props); mesh.position.set(px, 0, pz); mesh.castShadow = true; mesh.receiveShadow = true; scene.add(mesh);
        const col = { minX: px - .3, maxX: px + .3, minZ: pz - .3, maxZ: pz + .3, minY: 0, h: .9 }; colliders.push(col); barrels.push({ x: px, z: pz, mesh, col, alive: true }); } } }
  const tyre = new THREE.TorusGeometry(.32, .13, 8, 14);
  for (const [x, z, n] of [[-24, 56, 3], [-24.8, 55.2, 2], [24, 56, 3], [-44, -30, 2], [44, 30, 3], [-30, 10, 3]]) { for (let i = 0; i < n; i++) P.push(bake(tyre, 0x101112, [x, .13 + i * .26, z], [Math.PI / 2, 0, 0])); colliders.push({ minX: x - .45, maxX: x + .45, minZ: z - .45, maxZ: z + .45, minY: 0, h: n * .26 }); }
  // fuel tank farm
  for (const [x, z] of [[-52, 50], [-60, 54], [-52, 58]]) { pc(0x8a8f8c, [x, 3, z], 4, 4, 6, [0, 0, 0], 24); P.push(bake(new THREE.SphereGeometry(4, 20, 8, 0, 6.283, 0, Math.PI / 2), 0x9a9f9c, [x, 6, z])); pc(0x5a5f5c, [x, .4, z], 4.2, 4.2, .8, [0, 0, 0], 24); P.push(bake(new THREE.TorusGeometry(4.02, .08, 6, 24), 0x40464a, [x, 4.2, z], [Math.PI / 2, 0, 0])); P.push(limb([x + 3.4, .5, z], [x + 3.4, 6.4, z], .1, .1, 0x40464a, 6)); solid(x, z, 8, 8, 6); }
  // lamp posts
  const lampAt = (x, z, dir) => { P.push(bake(CYL(.07, .1, 5.2, 8), 0x3b4144, [x, 2.6, z])); P.push(bake(CYL(.2, .2, .15, 10), 0x2a2d2e, [x, .08, z])); P.push(limb([x, 5.1, z], [x + dir * .9, 5.35, z], .045, .04, 0x3b4144, 6)); pr(0x2a2d2e, [x + dir * 1.1, 5.3, z], .5, .1, .22, .03); pb(0xfff0c8, [x + dir * 1.1, 5.23, z], [.42, .03, .16]); colliders.push({ minX: x - .12, maxX: x + .12, minZ: z - .12, maxZ: z + .12, minY: 0, h: 5 }); };
  for (let z = -40; z <= 45; z += 20) { if (Math.abs(z) < 8) continue; lampAt(-5, z, 1); lampAt(5, z, -1); }
  for (let x = -60; x <= 60; x += 20) { if (Math.abs(x) < 8) continue; lampAt(x, -5, 0); lampAt(x + 10, 5, 0); }
  [[-14, 52], [14, 52], [-14, 68], [14, 68]].forEach(l => lampAt(l[0], l[1], l[0] > 0 ? -1 : 1));
  // rubble
  const rockC = [0x8a7f6c, 0x7b725f, 0x9a8f7a];
  for (let i = 0; i < 160; i++) { const b = B[i % B.length], a = rnd() * 6.28, x = b[0] + Math.cos(a) * (b[2] / 2 + 1.2 + rnd() * 3), z = b[1] + Math.sin(a) * (b[4] / 2 + 1.2 + rnd() * 3), rr = rnd() * .8 + .15; if (Math.abs(x) > 67 || Math.abs(z) > 67 || inRoad(x, z, -.5)) continue; P.push(bake(ICO, shade(rockC[i % 3], .15), [x, rr * .35, z], [rnd() * 3, rnd() * 3, 0], [rr, rr * .6, rr * .85])); }
  // boulder field SE + rocky outcrops (solid cover)
  for (let i = 0; i < 26; i++) { const x = 40 + rnd() * 26, z = 48 + rnd() * 18; if (!free(x, z, 3)) continue; const r = 1.2 + rnd() * 1.8; P.push(bake(ICO, shade(rockC[i % 3], .15), [x, r * .55, z], [rnd() * 3, rnd() * 3, 0], [r, r * .75, r * .9])); solid(x, z, r * 1.6, r * 1.6, r * 1.1); }
  // palms
  function palm(x, z, lean, h, sd) {
    const segs = 8, top = [0, 0, 0];
    for (let i = 0; i < segs; i++) { const t0 = i / segs, t1 = (i + 1) / segs, a = [lean * t0 * t0 * h, t0 * h], b = [lean * t1 * t1 * h, t1 * h]; P.push(bake(capsuleGeo(Math.hypot(b[0] - a[0], b[1] - a[1]), .2 - .08 * t0, .2 - .08 * t1, 6, 1, 1), shade(i % 2 ? 0x7a6544 : 0x6a583a, .08), [x + a[0], a[1], z], new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(b[0] - a[0], b[1] - a[1], 0).normalize()))); if (i === segs - 1) { top[0] = x + b[0]; top[1] = b[1]; top[2] = z; } }
    for (let f = 0; f < 11; f++) { const ang = f / 11 * 6.283 + sd, droop = .5 + (f % 3) * .22, len = 2.2 + (f % 2) * .5, q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, ang, 0)).multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, -droop))); P.push(bake(SPH, shade(f % 2 ? 0x4f6b3a : 0x5b7a40, .12), [top[0], top[1] + .1, top[2]], q, [len, .035, .32])); }
    for (let k = 0; k < 4; k++) pe(0x5a4630, [top[0] + Math.cos(k * 1.6) * .18, top[1] - .15, top[2] + Math.sin(k * 1.6) * .18], [.1, .13, .1]);
    colliders.push({ minX: x - .22, maxX: x + .22, minZ: z - .22, maxZ: z + .22, minY: 0, h: 6 });
  }
  let pi = 0; for (let i = 0; i < 26; i++) { const edge = i % 4, t = (rnd() - .5) * 120, x = edge < 2 ? (edge ? 65 : -65) : t, z = edge < 2 ? t : (edge === 2 ? 65 : -65); if (inRoad(x, z, 1)) continue; if (free(x, z, 1)) palm(x, z, (rnd() - .5) * .2, 6 + rnd() * 1.5, pi++); }
  for (let i = 0; i < 14; i++) { const x = (rnd() - .5) * 120, z = (rnd() - .5) * 120; if (free(x, z, 2.5)) palm(x, z, (rnd() - .5) * .2, 5 + rnd() * 2, pi++); }
  // dry shrubs scattered over the sand (one instanced draw call)
  { const SN = 420, sm = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({ roughness: 1, flatShading: true }), SN), m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), col = new THREE.Color(); let n = 0;
    for (let i = 0; i < 1400 && n < SN; i++) { const x = (rnd() - .5) * 132, z = (rnd() - .5) * 132; if (!free(x, z, 1.3)) continue; const s = .3 + rnd() * .55;
      q.setFromEuler(new THREE.Euler(0, rnd() * 6.28, 0)); m4.compose(new THREE.Vector3(x, s * .35, z), q, new THREE.Vector3(s * 1.4, s * .75, s * 1.4)); sm.setMatrixAt(n, m4); col.setHSL(.17 + rnd() * .1, .28 + rnd() * .2, .2 + rnd() * .14); sm.setColorAt(n, col); n++; }
    sm.count = n; sm.castShadow = true; sm.receiveShadow = true; scene.add(sm); }

  // ---------------- v13: OUTER ZONE (arena enlarged to 220 x 220 m) ----------------
  {
    // roads: axis roads continue to the walls, plus a ring road at 98 m
    roadPlane((68 + HALF) / 2, 0, HALF - 68, 8, .0092); roadPlane(-(68 + HALF) / 2, 0, HALF - 68, 8, .0092);
    roadPlane(0, -(46 + HALF) / 2, 8, HALF - 46, .0092); roadPlane(0, (68 + HALF) / 2, 8, HALF - 68, .0092);
    roadPlane(0, -98, 202, 6, .0088); roadPlane(0, 98, 202, 6, .0088); roadPlane(-98, 0, 6, 202, .0088); roadPlane(98, 0, 6, 202, .0088);
    for (let x = -100; x <= 100; x += 5) { dash(x, -98, false); dash(x, 98, false); }
    for (let z = -100; z <= 100; z += 5) { dash(-98, z, true); dash(98, z, true); }
    for (let x = 68; x < HALF - 2; x += 5) { dash(x, 0, false); dash(-x, 0, false); }
    for (let z = 69; z < HALF - 2; z += 5) dash(0, z, true);
    for (let z = -48; z > -HALF + 2; z -= 5) dash(0, z, true);
    for (let i = -80; i <= 80; i += 20) { lampAt(i, -95, 0); lampAt(i, 95, 0); lampAt(-95, i, 0); lampAt(95, i, 0); }
    const okb = (x, z, w, d) => free(x, z, Math.max(w, d) / 2 + 1.5);
    const bld = (x, z, w, h, d, f) => { if (okb(x, z, w, d)) building(x, z, w, h, d, f); };
    const cols = [0x7a2d22, 0x2d4f7a, 0x4a5a3a, 0x7a6a2d];
    // 4 corner outposts: lookout tower, buildings, sandbag nests, checkpoint barriers, containers
    for (const [sx, sz] of [[1, -1], [-1, -1], [1, 1], [-1, 1]]) {
      const cx = sx * 78, cz = sz * 78; tower(sx * 90, sz * 90);
      [[-8, 0, 14, 7, 10], [6, -10, 10, 12, 9], [10, 8, 9, 5, 9], [-10, 12, 8, 4, 8]].forEach(([ox, oz, w, h, d], i) => bld(cx + ox * sx, cz + oz * sz, w, h, d, i % 2 ? 1 : -1));
      [[-16, -4, false], [-16, 6, false], [0, -17, true], [12, -17, true], [-2, 18, true]].forEach(([ox, oz, a]) => { if (free(cx + ox * sx, cz + oz * sz, 3)) sandNest(cx + ox * sx, cz + oz * sz, a); });
      for (let i = 0; i < 5; i++) { const bx = cx + sx * (-20 + i * 2.4), bz = cz + sz * 22; if (free(bx, bz, 1.5)) barrier(bx, bz, i); }
      [[20, -6, false], [20, 4, false], [-20, 18, true]].forEach(([ox, oz, a], i) => { if (free(cx + ox * sx, cz + oz * sz, 4)) container(cx + ox * sx, cz + oz * sz, a, cols[(i + (sx > 0 ? 0 : 2)) % 4]); });
    }
    // 8 villages along the edges: low houses + one tall building (sniper vantage), crates, containers
    for (const [vx, vz] of [[84, -34], [84, 34], [-84, -34], [-84, 34], [-34, -84], [34, -84], [-34, 84], [34, 84]]) {
      bld(vx - 6, vz - 6, 12, 5, 9, 1); bld(vx + 7, vz + 3, 9, 4, 10, -1); bld(vx - 4, vz + 10, 8, 13, 8, 1);
      for (let k = 0; k < 4; k++) { const x = vx + (rnd() - .5) * 26, z = vz + (rnd() - .5) * 26; if (free(x, z, 1.5)) crate(x, z, 1.4, 1.4, 1.4); }
      if (free(vx + 12, vz - 9, 4)) container(vx + 12, vz - 9, rnd() < .5, cols[(rnd() * 4) | 0]);
      if (free(vx - 12, vz - 1, 3)) sandNest(vx - 12, vz - 1, rnd() < .5);
    }
    // fillers over the whole outer band
    const outer = (x, z) => Math.max(Math.abs(x), Math.abs(z)) > 66;
    for (let i = 0; i < 70; i++) { const x = (rnd() - .5) * 2 * (HALF - 6), z = (rnd() - .5) * 2 * (HALF - 6); if (outer(x, z) && free(x, z, 1.6)) crate(x, z, 1.4, 1.4, 1.4); }
    for (let i = 0; i < 18; i++) { const x = (rnd() - .5) * 2 * (HALF - 8), z = (rnd() - .5) * 2 * (HALF - 8); if (outer(x, z) && free(x, z, 4)) container(x, z, rnd() < .5, cols[i % 4]); }
    for (let i = 0; i < 26; i++) { const x = (rnd() - .5) * 2 * (HALF - 6), z = (rnd() - .5) * 2 * (HALF - 6); if (outer(x, z) && free(x, z, 1.6)) barrier(x, z, i); }
    let pj = 500; for (let i = 0; i < 46; i++) { const x = (rnd() - .5) * 2 * (HALF - 5), z = (rnd() - .5) * 2 * (HALF - 5); if (outer(x, z) && free(x, z, 2.5)) palm(x, z, (rnd() - .5) * .2, 5 + rnd() * 2, pj++); }
    for (let i = 0; i < 40; i++) { const x = (rnd() - .5) * 2 * (HALF - 6), z = (rnd() - .5) * 2 * (HALF - 6); if (!outer(x, z) || !free(x, z, 3)) continue; const r = 1.2 + rnd() * 1.8; P.push(bake(ICO, shade(rockC[i % 3], .15), [x, r * .55, z], [rnd() * 3, rnd() * 3, 0], [r, r * .75, r])); solid(x, z, r * 1.5, r * 1.5, r * 1.1); }
    const SN = 520, sm = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({ roughness: 1, flatShading: true }), SN), m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), col = new THREE.Color(); let n = 0;
    for (let i = 0; i < 3500 && n < SN; i++) { const x = (rnd() - .5) * 2 * (HALF - 5), z = (rnd() - .5) * 2 * (HALF - 5); if (!outer(x, z) || !free(x, z, 1.3)) continue; const s = .3 + rnd() * .55;
      q.setFromEuler(new THREE.Euler(0, rnd() * 6.28, 0)); m4.compose(new THREE.Vector3(x, s * .35, z), q, new THREE.Vector3(s * 1.4, s * .75, s * 1.4)); sm.setMatrixAt(n, m4); col.setHSL(.17 + rnd() * .1, .28, .3 + rnd() * .12); sm.setColorAt(n, col); n++; }
    sm.count = n; sm.instanceMatrix.needsUpdate = true; if (sm.instanceColor) sm.instanceColor.needsUpdate = true; sm.castShadow = true; sm.receiveShadow = true; scene.add(sm);
  }
  // ---------------- merge chunks ----------------
  const matFor = { props: mats.props, concrete: mats.concrete, crate: mats.crate };
  for (const [key, list] of chunks) { const kind = key.split('|')[0], m = new THREE.Mesh(mergeColored(list), matFor[kind]); m.castShadow = true; m.receiveShadow = true; scene.add(m); }
  // ---------------- sky dome + clouds + hills ----------------
  const sky = new THREE.SphereGeometry(300, 24, 14), pos = sky.attributes.position, cols = new Float32Array(pos.count * 3), hz = new THREE.Color(0xcfc6ae), zn = new THREE.Color(0x3f78bd), mid = new THREE.Color(0x9fbad2);
  for (let i = 0; i < pos.count; i++) { const t = Math.max(0, pos.getY(i) / 300), c = t < .3 ? hz.clone().lerp(mid, t / .3) : mid.clone().lerp(zn, (t - .3) / .7); cols[i * 3] = c.r; cols[i * 3 + 1] = c.g; cols[i * 3 + 2] = c.b; }
  sky.setAttribute('color', new THREE.BufferAttribute(cols, 3));
  const dome = new THREE.Mesh(sky, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false })); dome.renderOrder = -10; scene.add(dome);
  const cloudTex = canvasTex(128, 64, (x, w, h) => { for (let i = 0; i < 26; i++) { const cx = 34 + Math.random() * 60, g = x.createRadialGradient(cx, 32 + Math.random() * 6 - 3, 1, cx, 32, 12 + Math.random() * 8); g.addColorStop(0, 'rgba(255,255,255,.22)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, w, h); } });
  for (let i = 0; i < 12; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: cloudTex, transparent: true, depthWrite: false, fog: false, opacity: .9 })); const a = i / 12 * 6.28; s.position.set(Math.cos(a) * 220, 70 + (i % 3) * 18, Math.sin(a) * 220); s.scale.set(130, 46, 1); scene.add(s); }
  const hillMat = new THREE.MeshStandardMaterial({ color: 0x77877f, roughness: 1, flatShading: true });
  for (let i = 0; i < 34; i++) { const a = i / 34 * 6.283, d = HALF + 55 + rnd() * 35, m = new THREE.Mesh(new THREE.ConeGeometry(14 + rnd() * 14, 14 + rnd() * 26, 6), hillMat); m.position.set(Math.cos(a) * d, 3, Math.sin(a) * d); m.scale.z = .7; m.rotation.y = rnd() * 3; scene.add(m); }
  return { colliders, mats, half: HALF, isFreeSpot: free, barrels };
}
