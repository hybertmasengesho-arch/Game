// Thin WebSocket client for the co-op relay in server.js.
export class Net {
  constructor() { this.ws = null; this.id = 0; this.room = ''; this.host = 0; this.players = []; this.started = false; this.n = 35; this.open = false; this.h = {}; }
  on(type, fn) { this.h[type] = fn; return this; }
  get isHost() { return this.id !== 0 && this.id === this.host; }
  connect(url) {
    return new Promise((resolve, reject) => {
      let ws; try { ws = new WebSocket(url); } catch (e) { return reject(new Error('Bad server address')); }
      this.ws = ws; let settled = false;
      const fail = msg => { if (!settled) { settled = true; reject(new Error(msg)); } };
      const to = setTimeout(() => { fail('Server not reachable'); try { ws.close(); } catch { } }, 8000);
      ws.onopen = () => { clearTimeout(to); settled = true; this.open = true; resolve(); };
      ws.onerror = () => fail('Server not reachable');
      ws.onclose = () => { clearTimeout(to); const was = this.open; this.open = false; fail('Server not reachable'); if (was && this.h.close) this.h.close(); };
      ws.onmessage = ev => {
        let m; try { m = JSON.parse(ev.data); } catch { return; }
        if (m.t === 'joined') { this.id = m.id; this.room = m.room; this.host = m.host; this.started = m.started; this.n = m.n || 35; }
        else if (m.t === 'start') this.n = m.n || 35;
        else if (m.t === 'roster') { this.players = m.players; this.host = m.host; this.started = m.started; }
        const f = this.h[m.t]; if (f) f(m);
      };
    });
  }
  raw(o) { if (this.open && this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }
  lan(name) { this.raw({ t: 'lan', name }); }
  create(name) { this.raw({ t: 'create', name }); }
  join(room, name) { this.raw({ t: 'join', room, name }); }
  start() { this.raw({ t: 'start' }); }
  leave() { this.raw({ t: 'leave' }); }
  all(d) { this.raw({ t: 'msg', to: 'all', d }); }
  host_(d) { this.raw({ t: 'msg', to: 'host', d }); }
  to(id, d) { this.raw({ t: 'msg', to: id, d }); }
}
