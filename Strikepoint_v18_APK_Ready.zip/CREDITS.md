# Third-party assets
- `models/Soldier.glb`, `models/Soldier_lo.glb` — Mixamo "Vanguard" character with Idle/Walk/Run animations, taken from the three.js examples (mrdoob/three.js, `examples/models/gltf/Soldier.glb`). Textures resized, lo-poly variant made with gltf-transform/meshoptimizer. Mixamo assets are royalty-free for use in projects; check Adobe's terms before redistributing the raw files.
- `models/ferrari.glb` — "Ferrari 458 Italia" by vicent091036 (https://sketchfab.com/models/57bf6cc56931426e87494f554df1dab6), taken from the three.js examples. Interior removed and mesh decimated (~60k triangles) for phones. Check the licence on the Sketchfab page (credit the author if it is CC-BY) before publishing.
- Three.js (MIT), draco decoder (Apache-2.0).
