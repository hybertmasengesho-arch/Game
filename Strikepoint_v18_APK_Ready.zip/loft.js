// Lofted car bodies: a smooth 3D hull built from cross-sections along the length, with paint + glass split per quad.
import * as THREE from 'three';

const lerp = (a, b, t) => a + (b - a) * t, ss = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function hermite(keys, prop, z) {
  const n = keys.length; let i = 0; while (i < n - 2 && z > keys[i + 1].z) i++;
  const k0 = keys[i], k1 = keys[i + 1], h = k1.z - k0.z, t = Math.min(1, Math.max(0, (z - k0.z) / h));
  const slope = j => { const a = keys[Math.max(0, j - 1)], b = keys[Math.min(n - 1, j + 1)]; return (b[prop] - a[prop]) / Math.max(1e-6, b.z - a.z); };
  const m0 = slope(i) * h, m1 = slope(i + 1) * h, t2 = t * t, t3 = t2 * t;
  return (2 * t3 - 3 * t2 + 1) * k0[prop] + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * k1[prop] + (t3 - t2) * m1;
}
export function sampleBody(spec, z, prop) { return hermite(spec.keys, prop, Math.min(spec.keys[spec.keys.length - 1].z, Math.max(spec.keys[0].z, z))); }

function halfRing(hw, yLow, yBelt0, yTop, crown) {
  const yBelt = Math.min(yBelt0, yTop - .05), H = yTop - yBelt, th = hw * .8;
  const cab = [[0, yLow], [hw * .74, yLow], [hw * .95, yLow + .06], [hw * .995, yLow + (yBelt - yLow) * .5], [hw, yBelt],
    [lerp(hw, th, .18), yBelt + H * .28], [lerp(hw, th, .55), yBelt + H * .65], [lerp(hw, th, .95), yBelt + H * .94], [th * .55, yTop + crown * .65], [0, yTop + crown]];
  const lid = [[0, yLow], [hw * .74, yLow], [hw * .95, yLow + .06], [hw * .995, yLow + (yBelt - yLow) * .5], [hw, yBelt],
    [hw * .99, lerp(yBelt, yTop, .5)], [hw * .96, yTop - .02], [hw * .8, yTop + crown * .35], [hw * .48, yTop + crown * .8], [0, yTop + crown]];
  const t = ss(.1, .32, yTop - yBelt);
  return { pts: cab.map((c, i) => [lerp(lid[i][0], c[0], t), lerp(lid[i][1], c[1], t)]), t };
}
const inAny = (list, z) => list.some(([a, b]) => z >= a && z <= b);

/** spec: {keys:[{z,hw,yLow,yBelt,yTop,crown}], sideWin:[[z0,z1]], topWin:[[z0,z1]], n} -> {paint, glass} (indexed, shared vertex buffers) */
export function loftBody(spec) {
  const N = spec.n || 64, keys = spec.keys, z0 = keys[0].z, z1 = keys[keys.length - 1].z, rows = [];
  const mkRow = (z, sc = 1) => {
    const hw = hermite(keys, 'hw', z), yl = hermite(keys, 'yLow', z), yb = hermite(keys, 'yBelt', z), yt = hermite(keys, 'yTop', z), cr = hermite(keys, 'crown', z);
    const { pts: h, t } = halfRing(hw, yl, yb, yt, cr), ring = [...h, ...h.slice(1, 9).reverse().map(p => [-p[0], p[1]])];
    let cy = 0; for (const p of ring) cy += p[1]; cy /= ring.length; if (sc !== 1) for (const p of ring) { p[0] *= sc; p[1] = cy + (p[1] - cy) * sc; }
    return { z, ring, t };
  };
  for (const [d, s] of [[.1, .3], [.06, .65], [.03, .9]]) rows.push(mkRow(z0 - 0, 1) && { ...mkRow(z0, s), z: z0 - d });
  for (let j = 0; j <= N; j++) rows.push(mkRow(lerp(z0, z1, j / N)));
  for (const [d, s] of [[.03, .9], [.06, .65], [.1, .3]]) rows.push({ ...mkRow(z1, s), z: z1 + d });
  const R = rows.length, M = rows[0].ring.length, pos = new Float32Array((R * M + 2) * 3);
  rows.forEach((r, ri) => r.ring.forEach((p, i) => { pos.set([p[0], p[1], r.z], (ri * M + i) * 3); }));
  const cen = (ri) => { let x = 0, y = 0; for (const p of rows[ri].ring) { x += p[0]; y += p[1]; } return [x / M, y / M]; };
  const cA = R * M, cB = R * M + 1, ca = cen(0), cb = cen(R - 1); pos.set([ca[0], ca[1], rows[0].z - .02], cA * 3); pos.set([cb[0], cb[1], rows[R - 1].z + .02], cB * 3);
  const paint = [], glass = [], all = [];
  const hsOf = i => i <= 8 ? i : (i === 17 ? 0 : 17 - i);
  const tri = (list, a, b, c) => { list.push(a, b, c); all.push(a, b, c); };
  for (let r = 0; r < R - 1; r++) for (let i = 0; i < M; i++) {
    const a = r * M + i, b = r * M + (i + 1) % M, c = (r + 1) * M + (i + 1) % M, d = (r + 1) * M + i, zc = (rows[r].z + rows[r + 1].z) / 2, tAvg = (rows[r].t + rows[r + 1].t) / 2, hs = hsOf(i);
    let g = false; if (tAvg > .55) { if (hs >= 4 && hs <= 6) g = inAny(spec.sideWin, zc); else if (hs >= 7 && hs <= 8) g = inAny(spec.topWin, zc); }
    const L = g ? glass : paint; tri(L, a, b, c); tri(L, a, c, d);
  }
  for (let i = 0; i < M; i++) { tri(paint, cA, (i + 1) % M, i); tri(paint, cB, (R - 1) * M + i, (R - 1) * M + (i + 1) % M); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setIndex(all); geo.computeVertexNormals();
  // verify outward winding using the top-centre vertex of the middle row
  const mid = Math.floor(R / 2), ti = mid * M + 9; if (geo.attributes.normal.getY(ti) < 0) { for (const L of [paint, glass, all]) for (let k = 0; k < L.length; k += 3) { const t = L[k + 1]; L[k + 1] = L[k + 2]; L[k + 2] = t; } geo.setIndex(all); geo.computeVertexNormals(); }
  const uv = new Float32Array((R * M + 2) * 2), out = {};
  for (const [k, L] of [['paint', paint], ['glass', glass]]) { const g2 = new THREE.BufferGeometry(); g2.setAttribute('position', geo.attributes.position); g2.setAttribute('normal', geo.attributes.normal); g2.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); g2.setIndex(L); out[k] = g2; }
  return out;
}
