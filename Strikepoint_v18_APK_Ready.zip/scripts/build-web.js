// Copies the game (not the server / app tooling) into www/ for Capacitor.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'www');
const SKIP = new Set(['node_modules', 'www', 'android', '.git', '.github', 'scripts', 'resources', 'server.js', 'package.json', 'package-lock.json', 'capacitor.config.json', 'README.md', 'CREDITS.md', 'APP_SETUP.md', 'START_PC_SERVER.bat', 'start-server.sh', '.gitignore']);
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out);
(function copy(src, dst) {
  for (const f of fs.readdirSync(src)) {
    if (src === root && SKIP.has(f)) continue;
    const s = path.join(src, f), d = path.join(dst, f);
    if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else fs.copyFileSync(s, d);
  }
})(root, out);
console.log('Game copied to www/');
