# Strikepoint 3D — Operation Dustline (v11)

## What's new in v11 — CO-OP MULTIPLAYER (up to 5 players)
- **Crouch / zoom buttons removed.** Swipe down on the right side of the screen = crouch (swipe up = stand). Double tap the right side = zoom.
- **Multiplayer:** tap **MULTIPLAYER** on the start screen, type a callsign, then **CREATE NEW ROOM** (you get a 4-letter code) or enter a friend's code and **JOIN ROOM**. The host presses **START MISSION**. Up to 5 players per room; friends can also join mid-mission, and **COPY INVITE LINK** shares a ready-made link.
- **Co-op rules:** everyone fights the same 20 hostiles. The **host's phone runs the enemy AI**; everyone else sees the same enemies, hears the same gunfire and takes damage from the same bullets. Teammates appear as soldiers with name tags (visible through walls) and as cyan dots on the radar. Vehicles and explosive barrels are shared; a car being driven by a teammate shows as OCCUPIED. If you go down you respawn after 5 s. If the host leaves, the next player automatically becomes host. Mission ends when all hostiles are down.
- Single player (DEPLOY NOW) is unchanged and still works fully offline with just a static file server.

### Running a multiplayer server
Multiplayer needs the small Node server in this folder (`server.js`). It serves the game **and** relays the co-op messages, so players just open the same web address.
1. **Hosted (best for friends anywhere):** upload this folder to any Node host (Render, Railway, Fly.io, Glitch, Replit...). Build command `npm install`, start command `npm start`. Open the site's https address on every phone — the server field fills itself in.
2. **On your own Android phone (same Wi-Fi):** install Termux, then `pkg install nodejs`, `cd` to this folder, `npm install`, `npm start`. Friends open `http://<your-phone-ip>:3000` in their browsers.
3. **On a PC:** `npm install` then `npm start`, open `http://localhost:3000` (friends on the same network use your PC's IP).
Health check: `/healthz`. Port: the `PORT` environment variable (default 3000). If the game page is opened from a different site than the server, type the server address in the Server field (or use `?server=host:port`).
Invite links look like `https://your-site/?room=ABCD`.


Third-person / first-person Android-browser shooter built with Three.js. Everything is bundled locally (no CDN), so it works offline once served.

## What's new in v10 — real Blender/Mixamo-quality models
- **Enemies** are now animated, textured Mixamo soldiers (Idle / Walk / Run blended by speed) holding the rifle with arm IK, with tint variants for Rifleman / Heavy / Runner and a 4k-triangle version at distance. The old procedural soldiers remain as automatic fallback.
- **Sport car** is a real Ferrari 458 model (wheels spin and steer). Other cars are still procedural.
- Add your own: put glTF/GLB files in `models/` (`Soldier.glb` replaces the enemy; `ferrari.glb` replaces the sport car). Use `?models=0` in the URL to disable external models. Export from Blender as glTF 2.0 (.glb), keep characters under ~15k and cars under ~60k triangles, textures <= 1024 px.
- See CREDITS.md for licences.

## What was new in v9
- **Stealth awareness (Mafia-2 style)**: a top-centre chip shows UNSEEN (green) / SEARCHING (amber) / SPOTTED (red) with an alert meter; "?" and "!" icons float over enemies as they notice you; the radar shows enemy vision cones. When a guard first spots you a short "SPOTTED" clip cuts to his face (with a warning sting); when everyone loses you a calm "LOST THEM - YOU'RE UNSEEN" clip plays.
- **Cars**: see-through tinted glass with modelled interiors (dash, seats, mirror, steering wheel that turns), treaded tyres, chrome belt trim, wipers, fuel caps, hood scoop on the sport car, exhaust smoke.

## What was new in v8
- **Short movies** (skippable with the SKIP button / Enter / Cross): an intro fly-over with a helicopter and captions, a mission-complete outro with orbit camera and an extraction helicopter, and a death cam (slow orbit, desaturated).
- **Effects**: shootable explosive barrels (red with yellow band; chain reactions, fireball, smoke column, shockwave, sparks, damage and screen shake), ejected brass casings, muzzle smoke, blood spray, bullet-hole decals, car-crash sparks, slow-motion on headshot kills and the last kill.
- **Realism**: golden-hour lighting, environment reflections, surface bump detail, shrubs, vignette and film grain, wind ambience, gunshot echo, camera bob.

## What was new in v6
- **PS4 / DualSense / Xbox controller** (pair over Bluetooth, then press any button): left stick move, right stick look, R2 fire, L2 zoom, R1 sprint (hold), L3 sprint toggle, Cross jump, Circle crouch, Square reload, Triangle enter/exit vehicle, L1 camera, Options pause. In a vehicle: R2 gas, L2 brake/reverse, left stick steer, Cross/Circle handbrake. Rumble on fire/hit. Touch controls hide while a pad is connected.
- **Animations**: reload (rifle drops, hand goes to the magazine), recoil kick, hit flinch, idle breathing/weapon sway, death fall.

## What was new in v5
- **Crouch** (swipe down on the right side of the screen / `C`; swipe up to stand): lowers the character with bent knees, slower, harder to hit and to spot.
- **Zoom** (double tap the right side of the screen / `Z` / hold right mouse): shoulders the rifle, narrows the field of view, closer camera, slower look sensitivity.
- **Auto cover**: stop next to a crate, wall, barrier or building and you take cover automatically ("IN COVER"). Low cover = you crouch and the camera rises to look over it; tall walls = you press your back to the wall. Enemies hit you less in cover. Moving away (or sprinting) leaves cover.

## What was new in v4
- **Arena 4x bigger** (140 x 140 m): road network, town, industrial zone, fortified HQ compound with towers, tank farm, boulder field, checkpoints, radar minimap.
- **Enemy AI**: A* pathfinding on a nav grid, cover-peek-fire cycles, vision cones + hearing (gunshots, sprinting, engines), squad alerts, search behaviour, retreat when wounded, dodging your vehicle. Rifleman uses cover, Heavy advances with suppressive fire, Runner flanks then rushes. 20 enemies in 7 squads.
- **Cars re-shaped**: lofted 3D bodies with tumblehome, raked glass, pillars, wheel arches, lights. New Sport coupe and SUV, redesigned Sedan/Pickup/Jeep; 6 vehicles at spawn, 7 in the field.
- Enemy LOD, adaptive quality (auto-lowers on slow phones), health regen after 5 s unhurt.

## What was new in v3
- **Enemies rebuilt** with smooth organic geometry: capsule limbs, rounded armour plates, camo-painted uniforms, detailed helmets/goggles/faces, and fully modelled weapons (rifle, LMG with ammo box and bipod, suppressed SMG).
- **Player movement**: acceleration/inertia, walk / jog / sprint tiers (stick pushed to the edge or Shift or the RUN button sprints), a real run gait with forward lean, strafe and backpedal leg animation, jump tuck + landing dip, footstep audio, sprint FOV kick, camera that no longer clips into crates.
- **World**: windowed buildings with doors, roof gear and parapets, shipping containers, jersey barriers, plank-framed crates, sandbag bunker, ribbed drums, tyre stacks, lamp posts, palms, rubble, sky dome with clouds.

## What was new in v2
- **Your character** (the FBX from `walking-avatar.html`) is now the player: skinned model, IK walk cycle, and a two-handed rifle hold that follows your aim. Toggle **CAM** (or press `V`) for first person.
- **Vehicles**: Sedan, Jeep, Pickup (drivable) plus burnt-out wrecks as cover. Walk up and tap **ENTER** (or `E`). Run hostiles over for a ROADKILL.
- **Enemies**: three hand-built, articulated soldier types — Rifleman, Heavy (armoured, LMG) and Runner (fast SMG). Headshots deal triple damage, hostiles use cover/line of sight, and killing one scavenges ammo.
- Collision with walls, crates and vehicles; auto-fire; recoil recovery; engine and gunshot audio.

## Run it
Browsers block ES modules and the FBX download from `file://`, so serve the folder:

    cd Strikepoint_3D_Android_FPS
    python3 -m http.server 8080

Open `http://<your-computer-ip>:8080` on the phone (same Wi-Fi), or host the folder on any static host (GitHub Pages, Netlify, etc.). Landscape works best.

## Controls
| | Mobile | Desktop |
|---|---|---|
| Move / drive | left stick | WASD / arrows |
| Look | drag right side | mouse (click to lock) |
| Fire / handbrake-drift (in car) | FIRE | left click / Space |
| Reload | ↻ | R |
| Jump | ↑ | Space |
| Enter / exit vehicle | ENTER / EXIT | E |
| Camera | CAM | V |
| Pause | Ⅱ | Esc |

## Files
- `game.js` – main loop, input, camera, shooting, HUD
- `character.js` – FBX operator, IK walk + arm IK, rifle model
- `vehicles.js` – car models, driving physics, tyre smoke/skid marks
- `enemies.js` – soldier models, animation, AI
- `world.js` – arena, colliders; `utils.js`, `audio.js` – helpers
- `assets/character.fbx` – extracted from your avatar file; `lib/` – Three.js r164 + addons

## Performance notes
~240 draw calls, ~110k triangles with the operator in view. On slower phones lower `PR()` / shadow size in `game.js`, or hide the eyelash/teeth meshes of the operator.
