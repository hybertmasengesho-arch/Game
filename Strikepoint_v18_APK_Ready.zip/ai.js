// Enemy AI: navigation grid + A*, cover system, perception, squad alerts and per-role combat behaviour.
import { firstWallHit, resolveCircle, clamp, wrapPi, rand } from './utils.js';

// ====================================================================================================
//  Navigation grid + A* + cover slots
// ====================================================================================================
export class Nav {
  constructor(colliders, half, cell = 1.5) {
    this.half = half; this.cell = cell; const n = this.n = Math.ceil(2 * half / cell);
    this.blocked = new Uint8Array(n * n); this.soft = new Uint8Array(n * n);
    for (const c of colliders) { this._mark(c, .75, this.blocked); this._mark(c, 1.6, this.soft); }
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const x = (i + .5) * cell - half, z = (j + .5) * cell - half; if (Math.abs(x) > half - 1.6 || Math.abs(z) > half - 1.6) this.blocked[j * n + i] = 1; }
    this.g = new Float32Array(n * n); this.parent = new Int32Array(n * n); this.seen = new Int32Array(n * n); this.closed = new Int32Array(n * n); this.stamp = 0;
    this.hI = []; this.hF = [];
    this.buildCover(colliders);
  }
  _mark(c, r, arr) {
    const n = this.n, cs = this.cell, h = this.half;
    const x0 = Math.max(0, Math.floor((c.minX - r + h) / cs)), x1 = Math.min(n - 1, Math.floor((c.maxX + r + h) / cs));
    const z0 = Math.max(0, Math.floor((c.minZ - r + h) / cs)), z1 = Math.min(n - 1, Math.floor((c.maxZ + r + h) / cs));
    for (let j = z0; j <= z1; j++) for (let i = x0; i <= x1; i++) arr[j * n + i] = 1;
  }
  blockCircle(x, z, r) { const n = this.n, cs = this.cell, h = this.half; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const cx = (i + .5) * cs - h, cz = (j + .5) * cs - h; if ((cx - x) ** 2 + (cz - z) ** 2 < (r + .7) ** 2) this.blocked[j * n + i] = 1; } }
  idx(x, z) { const n = this.n, i = clamp(Math.floor((x + this.half) / this.cell), 0, n - 1), j = clamp(Math.floor((z + this.half) / this.cell), 0, n - 1); return j * n + i; }
  cx(i) { return (i % this.n + .5) * this.cell - this.half; } cz(i) { return (Math.floor(i / this.n) + .5) * this.cell - this.half; }
  isFree(x, z) { return !this.blocked[this.idx(x, z)]; }
  nearestFree(i, maxR = 7) {
    if (!this.blocked[i]) return i; const n = this.n, ci = i % n, cj = Math.floor(i / n);
    for (let r = 1; r <= maxR; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) { if (Math.max(Math.abs(di), Math.abs(dj)) !== r) continue; const a = ci + di, b = cj + dj; if (a < 0 || b < 0 || a >= n || b >= n) continue; if (!this.blocked[b * n + a]) return b * n + a; }
    return -1;
  }
  clearLine(ax, az, bx, bz) { const d = Math.hypot(bx - ax, bz - az), steps = Math.ceil(d / (this.cell * .5)); for (let k = 1; k < steps; k++) { const t = k / steps; if (this.blocked[this.idx(ax + (bx - ax) * t, az + (bz - az) * t)]) return false; } return true; }
  _push(i, f) { const I = this.hI, F = this.hF; let k = I.length; I.push(i); F.push(f); while (k > 0) { const p = (k - 1) >> 1; if (F[p] <= F[k]) break; [I[p], I[k]] = [I[k], I[p]]; [F[p], F[k]] = [F[k], F[p]]; k = p; } }
  _pop() { const I = this.hI, F = this.hF, top = I[0], li = I.pop(), lf = F.pop(); if (I.length) { I[0] = li; F[0] = lf; let k = 0; for (; ;) { let l = 2 * k + 1, r = l + 1, m = k; if (l < I.length && F[l] < F[m]) m = l; if (r < I.length && F[r] < F[m]) m = r; if (m === k) break; [I[m], I[k]] = [I[k], I[m]]; [F[m], F[k]] = [F[k], F[m]]; k = m; } } return top; }
  findPath(sx, sz, tx, tz) {
    const n = this.n; let s = this.nearestFree(this.idx(sx, sz)), t = this.nearestFree(this.idx(tx, tz)); if (s < 0 || t < 0) return null;
    if (s === t) return [[tx, tz]];
    const st = ++this.stamp, g = this.g, par = this.parent, seen = this.seen, closed = this.closed, bl = this.blocked, soft = this.soft;
    const tI = t % n, tJ = Math.floor(t / n); this.hI.length = 0; this.hF.length = 0;
    g[s] = 0; par[s] = -1; seen[s] = st; this._push(s, 0); let iter = 0, found = false;
    while (this.hI.length) {
      const cur = this._pop(); if (closed[cur] === st) continue; closed[cur] = st; if (cur === t) { found = true; break; } if (++iter > 7000) break;
      const ci = cur % n, cj = (cur - ci) / n;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
        if (!di && !dj) continue; const a = ci + di, b = cj + dj; if (a < 0 || b < 0 || a >= n || b >= n) continue; const ni = b * n + a; if (bl[ni] || closed[ni] === st) continue;
        if (di && dj && (bl[cj * n + a] || bl[b * n + ci])) continue;
        const ng = g[cur] + (di && dj ? 1.414 : 1) + (soft[ni] ? .9 : 0);
        if (seen[ni] !== st || ng < g[ni]) { seen[ni] = st; g[ni] = ng; par[ni] = cur; const dx = Math.abs(a - tI), dz = Math.abs(b - tJ); this._push(ni, ng + (dx + dz) + (1.414 - 2) * Math.min(dx, dz)); }
      }
    }
    if (!found) return null;
    const cells = []; for (let c = t; c !== -1; c = par[c]) cells.push(c); cells.reverse();
    let pts = cells.slice(1).map(c => [this.cx(c), this.cz(c)]); if (!pts.length) return [[tx, tz]];
    if (!this.blocked[this.idx(tx, tz)]) pts[pts.length - 1] = [tx, tz];
    // string-pulling smoothing
    const out = []; let ax = sx, az = sz, i = 0;
    while (i < pts.length) { let j = pts.length - 1; while (j > i && !this.clearLine(ax, az, pts[j][0], pts[j][1])) j--; out.push(pts[j]); ax = pts[j][0]; az = pts[j][1]; i = j + 1; }
    return out;
  }
  // ---------- cover slots: points hugging the sides/corners of tall solid objects ----------
  buildCover(colliders) {
    this.slots = []; this.hash = new Map(); const o = 1.25;
    for (const c of colliders) {
      if (c.h < 1.25) continue; const w = c.maxX - c.minX, d = c.maxZ - c.minZ; if (w < .9 && d < .9) continue;
      const pts = [[c.minX - o, c.minZ - o], [c.maxX + o, c.minZ - o], [c.minX - o, c.maxZ + o], [c.maxX + o, c.maxZ + o]];
      for (let x = c.minX + 2.5; x < c.maxX - 1; x += 5) pts.push([x, c.minZ - o], [x, c.maxZ + o]);
      for (let z = c.minZ + 2.5; z < c.maxZ - 1; z += 5) pts.push([c.minX - o, z], [c.maxX + o, z]);
      if (w < 3 && d < 3) pts.push([(c.minX + c.maxX) / 2, c.minZ - o], [(c.minX + c.maxX) / 2, c.maxZ + o], [c.minX - o, (c.minZ + c.maxZ) / 2], [c.maxX + o, (c.minZ + c.maxZ) / 2]);
      for (const [x, z] of pts) { if (!this.isFree(x, z)) continue; const s = { x, z, owner: null }; this.slots.push(s); const k = Math.floor(x / 12) + ',' + Math.floor(z / 12); let a = this.hash.get(k); if (!a) { a = []; this.hash.set(k, a); } a.push(s); }
    }
  }
  slotsNear(x, z, r) { const out = [], k0x = Math.floor((x - r) / 12), k1x = Math.floor((x + r) / 12), k0z = Math.floor((z - r) / 12), k1z = Math.floor((z + r) / 12); for (let a = k0x; a <= k1x; a++) for (let b = k0z; b <= k1z; b++) { const l = this.hash.get(a + ',' + b); if (l) for (const s of l) if ((s.x - x) ** 2 + (s.z - z) ** 2 < r * r) out.push(s); } return out; }
}

// ====================================================================================================
//  Director: shared services (LOS, path budget, cover search, noise + squad alerts)
// ====================================================================================================
export class Director {
  constructor(world, nav) { this.world = world; this.nav = nav; this.soldiers = []; this.budget = 3; this.time = 0; }
  update(dt) { this.budget = 3; this.time += dt; }
  los(ax, ay, az, bx, by, bz) { const dx = bx - ax, dy = by - ay, dz = bz - az, d = Math.hypot(dx, dy, dz); if (d < 1e-3) return true; return firstWallHit(ax, ay, az, dx / d, dy / d, dz / d, this.world.colliders, d) >= d - .06; }
  requestPath(b, tx, tz) {
    if (this.budget <= 0) return false; this.budget--; const r = b.s.root.position, p = this.nav.findPath(r.x, r.z, tx, tz);
    b.path = p; b.pathI = 0; b.pathTarget = { x: tx, z: tz }; b.repathT = 1.2 + Math.random() * .6; return true;
  }
  /** Find a slot hidden from the threat plus a nearby peek position that can see the threat. */
  findCover(b, tx, tz, o) {
    const r = b.s.root.position, cands = this.nav.slotsNear(r.x, r.z, o.searchR || 26); let best = null, bs = 1e9;
    for (const sl of cands) {
      if (sl.owner && sl.owner !== b) continue; const dt = Math.hypot(sl.x - tx, sl.z - tz); if (dt < o.minR || dt > o.maxR) continue;
      if (this.los(tx, 1.55, tz, sl.x, 1.45, sl.z)) continue;                                   // must be hidden from threat
      const ds = Math.hypot(sl.x - r.x, sl.z - r.z); let score = ds + Math.abs(dt - o.prefer) * .6; if (o.away) score -= dt * .8;
      if (score < bs) { bs = score; best = sl; }
    }
    if (!best) return null;
    // peek point: sample ring around cover, nearest spot with LOS to threat
    let peek = null, pd = 1e9;
    for (const rad of [1.6, 2.8, 4]) for (let k = 0; k < 10; k++) { const a = k / 10 * 6.283, px = best.x + Math.cos(a) * rad, pz = best.z + Math.sin(a) * rad; if (!this.nav.isFree(px, pz)) continue; if (!this.los(tx, 1.55, tz, px, 1.45, pz)) continue; const d = rad + Math.abs(wrapPi(a - Math.atan2(tz - best.z, tx - best.x))) * .3; if (d < pd) { pd = d; peek = { x: px, z: pz }; } }
    return { slot: best, peek: peek || { x: best.x + (tx - best.x) * .12, z: best.z + (tz - best.z) * .12 } };
  }
  makeNoise(x, z, r) { for (const s of this.soldiers) if (s.alive && Math.hypot(s.root.position.x - x, s.root.position.z - z) < r) s.brain.hear(x, z); }
  alertSquad(b, x, z) { for (const s of this.soldiers) if (s !== b.s && s.alive && s.squad === b.s.squad && Math.hypot(s.root.position.x - b.s.root.position.x, s.root.position.z - b.s.root.position.z) < 40) s.brain.hear(x, z, true); }
}

// ====================================================================================================
//  Brain: one per soldier
// ====================================================================================================
export class Brain {
  constructor(sol, dir, patrol) {
    this.s = sol; this.dir = dir; this.state = 'patrol'; this.patrol = patrol && patrol.length ? patrol : null; this.pi = Math.floor(Math.random() * (patrol ? patrol.length : 1)); this.wait = rand(.3, 2);
    this.path = null; this.pathI = 0; this.pathTarget = null; this.repathT = 0; this.awareness = 0; this.sees = false; this.senseT = rand(0, .2); this.lastKnown = null; this.lastSeen = -99; this.lastVel = { x: 0, z: 0 };
    this.reactT = 0; this.sub = 'new'; this.subT = 0; this.cover = null; this.peek = null; this.coverT = 0; this.flank = null; this.flankSide = Math.random() < .5 ? 1 : -1;
    this.stuckT = 0; this.lastPos = { x: sol.root.position.x, z: sol.root.position.z }; this.burst = 0; this.burstT = 0; this.fireCd = rand(.5, 1.2); this.aimLock = 0; this.suppressedT = 0;
    this.lookT = 0; this.lookA = 0; this.searchLeft = 0; this.evadeT = 0; this.evadeX = 0; this.evadeZ = 0; this.retreatT = 0; this.faceHold = null; this.sidestepT = rand(1, 3); this.sideDir = Math.random() < .5 ? 1 : -1;
  }
  // ---------------- events ----------------
  hear(x, z, fromSquad) {
    if (this.state === 'combat' || this.state === 'evade' || this.state === 'retreat') { if (fromSquad && !this.sees) this.lastKnown = { x, z }; return; }
    this.state = 'invest'; this.lastKnown = { x: x + rand(-3, 3), z: z + rand(-3, 3) }; this.reactT = rand(.25, .8); this.awareness = Math.max(this.awareness, .55); this.path = null; this.lookT = 0;
  }
  onHit(px, pz) {
    this.awareness = 1.5; this.lastKnown = { x: px, z: pz }; this.lastSeen = this.dir.time; this.suppressedT = 1.6;
    if (this.state !== 'combat') { this.state = 'combat'; this.sub = 'new'; this.reactT = .1; this.dir.alertSquad(this, px, pz); }
    if (this.cover && this.sub === 'fire') this.sub = 'back';
    if (this.s.hp < this.s.T.hp * .3 && this.s.typeKey !== 'heavy' && this.state !== 'retreat') { this.state = 'retreat'; this.cover = null; this.path = null; this.retreatT = rand(7, 11); }
  }
  releaseCover() { if (this.cover && this.cover.slot.owner === this) this.cover.slot.owner = null; this.cover = null; }
  // ---------------- perception ----------------
  sense(dist, dx, dz, ctx) {
    const p = ctx.player, r = this.s.root.position; const range = (p.inCar ? 62 : 46) * (p.sprint ? 1.15 : 1); let see = false;
    if (dist < range) {
      const ang = Math.abs(wrapPi(Math.atan2(dx, dz) - this.s.root.rotation.y)), cone = ang < 1.15 || this.state === 'combat' || dist < 10;
      if (cone) see = this.dir.los(r.x, 1.55, r.z, p.x, p.inCar ? 1.2 : p.y - .35, p.z);
    }
    this.sees = see;
    if (see) {
      const gain = ((1.25 - dist / range) * (this.state === 'combat' ? 3 : 1.7) + (dist < 10 ? 3 : 0)) * .2; this.awareness = Math.min(1.5, this.awareness + gain);
      this.lastKnown = { x: p.x, z: p.z }; this.lastSeen = ctx.time; this.lastVel = { x: p.vx, z: p.vz }; this.aimLock = Math.min(1, this.aimLock + .1);
    } else { this.awareness = Math.max(0, this.awareness - .05); this.aimLock = Math.max(0, this.aimLock - .1); }
    if (this.awareness >= 1 && this.state !== 'combat' && this.state !== 'evade' && this.state !== 'retreat') this.spot();
  }
  spot() { this.state = 'combat'; this.sub = 'new'; this.reactT = rand(.35, .85); this.path = null; if (this.lastKnown) this.dir.alertSquad(this, this.lastKnown.x, this.lastKnown.z); }
  // ---------------- movement helpers ----------------
  goTo(tx, tz, speed, out, dt, arrive = .9) {
    const r = this.s.root.position, d = Math.hypot(tx - r.x, tz - r.z); if (d < arrive) { this.path = null; return true; }
    this.repathT -= dt;
    if (!this.path || this.repathT <= 0 || (this.pathTarget && Math.hypot(this.pathTarget.x - tx, this.pathTarget.z - tz) > 3)) {
      if (!this.dir.requestPath(this, tx, tz) && !this.path) { out.vx = (tx - r.x) / d * speed; out.vz = (tz - r.z) / d * speed; out.speed = speed; return false; }
    }
    if (!this.path || this.pathI >= this.path.length) { if (this.path === null) { out.vx = (tx - r.x) / d * speed * .6; out.vz = (tz - r.z) / d * speed * .6; out.speed = speed * .6; } return !!this.path && this.pathI >= this.path.length; }
    const wp = this.path[this.pathI], wd = Math.hypot(wp[0] - r.x, wp[1] - r.z), last = this.pathI === this.path.length - 1;
    if (wd < (last ? arrive * .7 : .9)) { this.pathI++; if (this.pathI >= this.path.length) { this.path = null; return true; } return false; }
    out.vx = (wp[0] - r.x) / wd * speed; out.vz = (wp[1] - r.z) / wd * speed; out.speed = speed;
    // stuck detection
    this.stuckT += dt; if (this.stuckT > .6) { const m = Math.hypot(r.x - this.lastPos.x, r.z - this.lastPos.z); if (m < .18) { this.path = null; this.repathT = 0; } this.lastPos.x = r.x; this.lastPos.z = r.z; this.stuckT = 0; }
    return false;
  }
  gun(out, dt, canShoot, suppress, ctx) {
    const T = this.s.T; if (this.reactT > 0) return; this.fireCd -= dt;
    if (this.burst > 0) { this.burstT -= dt; if (this.burstT <= 0) { this.burst--; this.burstT = T.rate; out.fire = true; out.suppress = suppress; } }
    else if (this.fireCd <= 0 && canShoot) { this.burst = T.burst; this.burstT = 0; this.fireCd = rand(T.gap[0], T.gap[1]) * (suppress ? .75 : 1); }
  }
  spread(ctx, moving) {
    const T = this.s.T, p = ctx.player;
    return T.aim * (1 + p.speed * .09) * (1 + (1 - this.aimLock) * 2.6) * (this.suppressedT > 0 ? 1.7 : 1) * (moving ? 1.45 : 1) * (p.inCar ? .85 : 1);
  }
  // ---------------- main update ----------------
  update(dt, ctx) {
    const s = this.s, r = s.root.position, p = ctx.player, T = s.T, dx = p.x - r.x, dz = p.z - r.z, dist = Math.hypot(dx, dz) || .001;
    const out = { vx: 0, vz: 0, speed: 0, face: null, fire: false, suppress: false, spread: 0, tx: p.x, tz: p.z, moving: false };
    this.suppressedT = Math.max(0, this.suppressedT - dt); this.reactT = Math.max(0, this.reactT - dt); this.coverT -= dt;
    this.senseT -= dt; if (this.senseT <= 0) { this.senseT = .16 + Math.random() * .06; this.sense(dist, dx, dz, ctx); }
    // dodge an oncoming player vehicle
    if (p.inCar && p.speed > 7 && dist < 20 && this.state !== 'evade') {
      const vx = p.vx / p.speed, vz = p.vz / p.speed, toX = -dx / dist, toZ = -dz / dist; if (vx * toX + vz * toZ > .55) { this.state = 'evade'; this.evadeT = 1.1; const side = Math.sign(vx * (r.z - p.z) - vz * (r.x - p.x)) || 1; this.evadeX = -vz * side; this.evadeZ = vx * side; this.path = null; }
    }
    const faceP = Math.atan2(dx, dz), tgt = ctx.player;
    switch (this.state) {
      case 'patrol': this.doPatrol(dt, out); break;
      case 'invest': this.doInvest(dt, out); break;
      case 'search': this.doSearch(dt, out); break;
      case 'evade': this.evadeT -= dt; out.vx = this.evadeX * T.speed * 1.5; out.vz = this.evadeZ * T.speed * 1.5; out.speed = T.speed * 1.5; out.moving = true; if (this.evadeT <= 0) this.state = 'combat'; break;
      case 'retreat': this.doRetreat(dt, ctx, out, dist); break;
      case 'combat': this.doCombat(dt, ctx, out, dist, faceP); break;
    }
    if (out.speed > 0) out.moving = true;
    out.spread = this.spread(ctx, out.moving);
    return out;
  }
  // ---------------- states ----------------
  doPatrol(dt, out) {
    const T = this.s.T; if (this.lookT > 0) { this.lookT -= dt; out.face = this.lookA; return; }
    if (!this.patrol) { this.wait -= dt; if (this.wait <= 0) { this.lookA = Math.random() * 6.28; this.lookT = rand(1.5, 3); this.wait = rand(2, 5); } out.face = this.lookA; return; }
    const w = this.patrol[this.pi];
    if (this.goTo(w[0], w[1], T.speed * .5, out, dt, 1.2)) { this.pi = (this.pi + 1) % this.patrol.length; this.lookA = Math.random() * 6.28; this.lookT = rand(1.2, 3.2); }
  }
  doInvest(dt, out) {
    const T = this.s.T; if (this.reactT > 0) { return; } if (this.lookT > 0) { this.lookT -= dt; out.face = this.lookA; if (this.lookT <= 0) { this.state = 'search'; this.searchLeft = 2; this.path = null; } return; }
    if (!this.lastKnown) { this.state = 'patrol'; return; }
    if (this.goTo(this.lastKnown.x, this.lastKnown.z, T.speed * .85, out, dt, 1.6)) { this.lookA = this.s.root.rotation.y + rand(-2, 2); this.lookT = rand(2, 3.5); }
  }
  doSearch(dt, out) {
    const T = this.s.T, r = this.s.root.position;
    if (this.lookT > 0) { this.lookT -= dt; out.face = this.lookA + Math.sin(this.lookT * 2.5) * .8; return; }
    if (!this.searchPt) { const k = this.lastKnown || { x: r.x, z: r.z }; for (let i = 0; i < 8; i++) { const a = Math.random() * 6.28, d = rand(4, 11), x = k.x + Math.cos(a) * d, z = k.z + Math.sin(a) * d; if (this.dir.nav.isFree(x, z)) { this.searchPt = { x, z }; break; } } if (!this.searchPt) this.searchPt = { x: k.x, z: k.z }; }
    if (this.goTo(this.searchPt.x, this.searchPt.z, T.speed * .7, out, dt, 1.4)) { this.searchPt = null; this.searchLeft--; this.lookA = Math.random() * 6.28; this.lookT = rand(1.5, 2.6); if (this.searchLeft <= 0) { this.state = 'patrol'; this.awareness = 0; this.aimLock = 0; this.path = null; this.releaseCover(); } }
  }
  doRetreat(dt, ctx, out, dist) {
    const T = this.s.T, p = ctx.player; this.retreatT -= dt;
    if (!this.cover) { const c = this.dir.findCover(this, p.x, p.z, { minR: 16, maxR: 70, prefer: 30, searchR: 40, away: true }); if (c) { this.cover = c; c.slot.owner = this; } else { this.state = 'combat'; this.sub = 'new'; return; } }
    const at = this.goTo(this.cover.slot.x, this.cover.slot.z, T.speed * 1.2, out, dt, 1.0);
    if (at) { out.face = Math.atan2(p.x - this.s.root.position.x, p.z - this.s.root.position.z); if (this.retreatT <= 0) { this.state = 'combat'; this.sub = 'new'; this.s.hp = Math.min(this.s.T.hp * .5, this.s.hp + this.s.T.hp * .15); } }
  }
  doCombat(dt, ctx, out, dist, faceP) {
    const s = this.s, T = s.T, p = ctx.player, r = s.root.position, key = s.typeKey, stale = ctx.time - this.lastSeen;
    const tx = this.lastKnown ? this.lastKnown.x : p.x, tz = this.lastKnown ? this.lastKnown.z : p.z;
    out.tx = this.sees ? p.x : tx; out.tz = this.sees ? p.z : tz;
    if (this.reactT > 0) { out.face = Math.atan2(tx - r.x, tz - r.z); return; }
    if (stale > 4.5 && !this.sees) { this.state = 'search'; this.searchLeft = 2; this.searchPt = null; this.path = null; this.releaseCover(); return; }
    const face = Math.atan2(out.tx - r.x, out.tz - r.z), aimed = Math.abs(wrapPi(face - s.root.rotation.y)) < .4;
    out.face = face;
    const canShoot = this.sees && aimed, suppress = !this.sees && stale < 5 && dist < 40;
    if (key === 'heavy' && s.hp > T.hp * .35) {                                        // ---- heavy: advance under suppressive fire
      this.sidestepT -= dt; if (this.sidestepT <= 0) { this.sidestepT = rand(1.5, 3.5); this.sideDir *= -1; }
      if (!this.sees || dist > s.prefer + 3) { this.goTo(tx, tz, T.speed, out, dt, s.prefer * .8); }
      else { const px = -(tz - r.z) / dist, pz = (tx - r.x) / dist; out.vx = px * this.sideDir * T.speed * .35; out.vz = pz * this.sideDir * T.speed * .35; out.speed = T.speed * .35; }
      this.gun(out, dt, canShoot, suppress, ctx); return;
    }
    if (key === 'runner' && s.hp > T.hp * .3) {                                        // ---- runner: flank, then rush
      if (this.sub !== 'rush') {
        if (!this.flank || this.sub === 'new') { const base = Math.atan2(r.z - p.z, r.x - p.x), a = base + this.flankSide * rand(.9, 1.3), fx = p.x + Math.cos(a) * rand(11, 16), fz = p.z + Math.sin(a) * rand(11, 16); this.flank = this.dir.nav.isFree(fx, fz) ? { x: fx, z: fz } : { x: p.x + Math.cos(base) * 12, z: p.z + Math.sin(base) * 12 }; this.sub = 'flank'; this.path = null; }
        const done = this.goTo(this.flank.x, this.flank.z, T.speed, out, dt, 2); if (done || (this.sees && dist < 16)) this.sub = 'rush';
        this.gun(out, dt, canShoot && dist < 26, suppress, ctx);
      } else {
        this.sidestepT -= dt; if (this.sidestepT <= 0) { this.sidestepT = rand(.6, 1.6); this.sideDir *= -1; }
        if (dist > 8) this.goTo(tx, tz, T.speed, out, dt, 6); else { const px = -(tz - r.z) / dist, pz = (tx - r.x) / dist; out.vx = px * this.sideDir * T.speed * .8 - (tx - r.x) / dist * T.speed * (dist < 5 ? .6 : 0); out.vz = pz * this.sideDir * T.speed * .8 - (tz - r.z) / dist * T.speed * (dist < 5 ? .6 : 0); out.speed = T.speed * .8; }
        this.gun(out, dt, canShoot, suppress, ctx); if (!this.sees && stale > 2.5) { this.sub = 'new'; this.flank = null; this.flankSide *= -1; }
      }
      return;
    }
    // ---- rifleman (and wounded heavies/runners): cover -> peek -> fire cycle
    if (this.sub === 'new' || (!this.cover && this.coverT <= 0) || this.coverT <= -8 || (this.suppressedT > 1.2 && this.sub === 'fire')) this.pickCover(ctx, dist);
    switch (this.sub) {
      case 'moveCover': { if (!this.cover) { this.sub = 'open'; break; } const at = this.goTo(this.cover.slot.x, this.cover.slot.z, T.speed * 1.15, out, dt, .9); if (at) { this.sub = 'hide'; this.subT = rand(1, 2.4); } this.gun(out, dt, canShoot, suppress, ctx); break; }
      case 'hide': { out.face = faceP; this.subT -= dt; if (this.subT <= 0) { this.sub = 'peek'; this.path = null; } break; }
      case 'peek': { const at = this.goTo(this.peek.x, this.peek.z, T.speed * .9, out, dt, .6); this.gun(out, dt, canShoot, false, ctx); if (at) { this.sub = 'fire'; this.subT = rand(1.8, 3.4); } break; }
      case 'fire': { this.gun(out, dt, canShoot, suppress, ctx); this.subT -= dt; if (this.subT <= 0 || !this.sees && this.subT < 1.2) { this.sub = 'back'; this.path = null; } break; }
      case 'back': { const at = this.goTo(this.cover.slot.x, this.cover.slot.z, T.speed * 1.1, out, dt, .9); this.gun(out, dt, canShoot, suppress, ctx); if (at) { this.sub = 'hide'; this.subT = rand(1.2, 2.8); } break; }
      default: {                                                                         // open ground fallback: keep range + strafe
        this.sidestepT -= dt; if (this.sidestepT <= 0) { this.sidestepT = rand(1, 2.4); this.sideDir *= -1; }
        if (dist > s.prefer + 4 || !this.sees) this.goTo(tx, tz, T.speed, out, dt, s.prefer);
        else { const px = -(tz - r.z) / dist, pz = (tx - r.x) / dist, bk = dist < s.prefer - 4 ? -.5 : 0; out.vx = px * this.sideDir * T.speed * .5 + (tx - r.x) / dist * bk * T.speed; out.vz = pz * this.sideDir * T.speed * .5 + (tz - r.z) / dist * bk * T.speed; out.speed = T.speed * .5; }
        this.gun(out, dt, canShoot, suppress, ctx); if (this.coverT <= 0) this.pickCover(ctx, dist);
      }
    }
  }
  pickCover(ctx, dist) {
    const p = ctx.player, tx = this.lastKnown ? this.lastKnown.x : p.x, tz = this.lastKnown ? this.lastKnown.z : p.z;
    this.releaseCover(); const c = this.dir.findCover(this, tx, tz, { minR: 7, maxR: 38, prefer: this.s.prefer, searchR: 28 });
    this.coverT = rand(9, 15);
    if (c) { this.cover = c; this.peek = c.peek; c.slot.owner = this; this.sub = 'moveCover'; this.path = null; } else this.sub = 'open';
  }
}
