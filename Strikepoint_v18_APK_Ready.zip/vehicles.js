import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { resolveCircle, clamp, roundBox } from './utils.js';
import { loftBody, sampleBody } from './loft.js';
import { M as MODELS } from './models.js';

const BX = new THREE.BoxGeometry(1, 1, 1);
const CYL = (rt, rb, h, s = 16) => new THREE.CylinderGeometry(rt, rb, h, s);
const PLN = (w, h) => new THREE.PlaneGeometry(w, h);

// ---------- reflections for paint / glass / chrome ----------
export function makeEnv(renderer) {
  try {
    const c = document.createElement('canvas'); c.width = 512; c.height = 256; const x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, '#4c8fd8'); g.addColorStop(.46, '#d5e9f8'); g.addColorStop(.5, '#8a8f7a'); g.addColorStop(.56, '#55663f'); g.addColorStop(1, '#2f3a27');
    x.fillStyle = g; x.fillRect(0, 0, 512, 256);
    const sg = x.createRadialGradient(150, 55, 2, 150, 55, 45); sg.addColorStop(0, '#fff'); sg.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = sg; x.fillRect(90, 0, 120, 110);
    const t = new THREE.CanvasTexture(c); t.mapping = THREE.EquirectangularReflectionMapping; t.colorSpace = THREE.SRGBColorSpace;
    const pm = new THREE.PMREMGenerator(renderer), env = pm.fromEquirectangular(t).texture; t.dispose(); pm.dispose(); return env;
  } catch (e) { return null; }
}

let SH = null; const paintCache = new Map();
function shared(env) {
  if (SH) return SH;
  SH = {
    glass: new THREE.MeshStandardMaterial({ color: 0x0a1218, metalness: .6, roughness: .08, envMap: env, envMapIntensity: 1.0, transparent: true, opacity: .5, depthWrite: false, side: THREE.DoubleSide }),
    chrome: new THREE.MeshStandardMaterial({ color: 0xe2e6ea, metalness: 1, roughness: .12, envMap: env }),
    plastic: new THREE.MeshStandardMaterial({ color: 0x141517, roughness: .55, metalness: .1 }),
    rubber: new THREE.MeshStandardMaterial({ color: 0x08090a, roughness: .9 }),
    rimM: new THREE.MeshStandardMaterial({ color: 0xc4c9d0, metalness: .9, roughness: .25, envMap: env, envMapIntensity: .7 }),
    steelRim: new THREE.MeshStandardMaterial({ color: 0x55595c, metalness: .6, roughness: .5 }),
    headM: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff0c8, emissiveIntensity: .7, roughness: .1, metalness: .2 }),
    plateM: new THREE.MeshStandardMaterial({ color: 0xf2f2f0, roughness: .6 }),
    seat: new THREE.MeshStandardMaterial({ color: 0x2a2c27, roughness: .9 }),
    bedLiner: new THREE.MeshStandardMaterial({ color: 0x1b1c1e, roughness: .95 }),
  };
  return SH;
}
function paintMat(env, color, kind) {
  const k = color + kind; if (paintCache.has(k)) return paintCache.get(k);
  const m = kind === 'matte' ? new THREE.MeshStandardMaterial({ color, roughness: .78, metalness: .12 })
    : kind === 'burnt' ? new THREE.MeshStandardMaterial({ color, roughness: 1, metalness: .15 })
      : new THREE.MeshPhysicalMaterial({ color, metalness: .5, roughness: .32, clearcoat: 1, clearcoatRoughness: .05, envMap: env, envMapIntensity: .55 });
  paintCache.set(k, m); return m;
}

// Collects pieces per material, then merges into one mesh per material -> few draw calls.
class Collector {
  constructor() { this.map = new Map(); this.m4 = new THREE.Matrix4(); this.q = new THREE.Quaternion(); this.e = new THREE.Euler(); }
  add(geo, mat, p = [0, 0, 0], r = [0, 0, 0], s = [1, 1, 1]) {
    const g = geo.clone();
    this.m4.compose(new THREE.Vector3(p[0], p[1], p[2]), this.q.setFromEuler(this.e.set(r[0], r[1], r[2])), new THREE.Vector3(s[0], s[1], s[2]));
    g.applyMatrix4(this.m4);
    const ng = g.index ? g.toNonIndexed() : g;
    for (const k of Object.keys(ng.attributes)) if (!['position', 'normal', 'uv'].includes(k)) ng.deleteAttribute(k);
    if (!this.map.has(mat)) this.map.set(mat, []); this.map.get(mat).push(ng);
  }
  box(mat, p, s, r) { this.add(BX, mat, p, r || [0, 0, 0], s); }
  build(parent) {
    for (const [mat, list] of this.map) { const m = new THREE.Mesh(mergeGeometries(list, false), mat); m.castShadow = true; m.receiveShadow = false; parent.add(m); }
  }
}

// ---------- side-profile extrusion helpers (from the avatar demo) ----------
const chaikin = (pts, n) => { for (let k = 0; k < n; k++) { const o = []; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; o.push([a[0] * .75 + b[0] * .25, a[1] * .75 + b[1] * .25], [a[0] * .25 + b[0] * .75, a[1] * .25 + b[1] * .75]); } pts = o; } return pts; };
const smoothN = g => {
  const p = g.attributes.position, n = g.attributes.normal, mp = new Map(), key = i => Math.round(p.getX(i) * 500) + ',' + Math.round(p.getY(i) * 500) + ',' + Math.round(p.getZ(i) * 500);
  for (let i = 0; i < p.count; i++) { const k = key(i); let e = mp.get(k); if (!e) { e = [0, 0, 0]; mp.set(k, e); } e[0] += n.getX(i); e[1] += n.getY(i); e[2] += n.getZ(i); }
  for (let i = 0; i < p.count; i++) { const e = mp.get(key(i)), l = Math.hypot(e[0], e[1], e[2]) || 1; n.setXYZ(i, e[0] / l, e[1] / l, e[2] / l); } n.needsUpdate = true;
};
const prof = (pts, w, bev) => {
  const sh = new THREE.Shape(); pts.forEach((p, i) => i ? sh.lineTo(p[0], p[1]) : sh.moveTo(p[0], p[1])); sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: w - 2 * bev, bevelEnabled: bev > 0, bevelSize: bev, bevelThickness: bev, bevelSegments: 4, curveSegments: 8 });
  g.translate(0, 0, -(w - 2 * bev) / 2); g.rotateY(-Math.PI / 2); g.computeVertexNormals(); if (bev > 0) smoothN(g); return g;
};

// ---------- wheels ----------
function wheelGeos(r, w, style) {
  const k = r / .362;
  const tire = new THREE.LatheGeometry([[.2, -.12], [.3, -.12], [.34, -.1], [.356, -.075], [.362, -.06], [.346, -.045], [.362, -.03], [.362, -.012], [.346, .0], [.362, .012], [.362, .03], [.346, .045], [.362, .06], [.356, .075], [.34, .1], [.3, .12], [.2, .12]].map(p => new THREE.Vector2(p[0] * k, p[1] * k * (w / .24))), 28);
  tire.rotateZ(Math.PI / 2);
  const parts = [];
  const add = (g, p, rot) => { const c = g.clone(); if (rot) c.rotateX(rot[0]).rotateY(rot[1]).rotateZ(rot[2]); c.translate(p[0], p[1], p[2]); const n = c.index ? c.toNonIndexed() : c; for (const kk of Object.keys(n.attributes)) if (!['position', 'normal', 'uv'].includes(kk)) n.deleteAttribute(kk); parts.push(n); };
  add(CYL(.215 * k, .215 * k, .2 * k, 28), [.02 * k, 0, 0], [0, 0, Math.PI / 2]);
  if (style === 'multi') for (let i = 0; i < 10; i++) add(new THREE.BoxGeometry(.022 * k, .4 * k, .04 * k), [.1 * k, 0, 0], [i * Math.PI / 10, 0, 0]);
  else if (style === 'spoke') for (let i = 0; i < 5; i++) add(new THREE.BoxGeometry(.03 * k, .4 * k, .05 * k), [.1 * k, 0, 0], [i * Math.PI / 5, 0, 0]);
  else { for (let i = 0; i < 6; i++) add(new THREE.BoxGeometry(.04 * k, .08 * k, .08 * k), [.12 * k, .13 * k * Math.cos(i * Math.PI / 3), .13 * k * Math.sin(i * Math.PI / 3)], [0, 0, 0]); }
  add(CYL(.055 * k, .055 * k, .04 * k, 16), [.115 * k, 0, 0], [0, 0, Math.PI / 2]);
  const rim = mergeGeometries(parts, false);
  return { tire, rim };
}

// ---------- models ----------
const SPH = new THREE.SphereGeometry(1, 14, 10);
const roundBoxG = (w, h, d, r) => roundBox(w, h, d, r, 3);
const SPECS = {
  sedan: { keys: [
    { z: -2.25, hw: .78, yLow: .36, yBelt: .62, yTop: .86, crown: .02 }, { z: -2.05, hw: .86, yLow: .33, yBelt: .7, yTop: .97, crown: .03 }, { z: -1.55, hw: .9, yLow: .3, yBelt: .76, yTop: .99, crown: .03 },
    { z: -1.2, hw: .92, yLow: .3, yBelt: .78, yTop: 1.08, crown: .04 }, { z: -.85, hw: .93, yLow: .3, yBelt: .78, yTop: 1.34, crown: .05 }, { z: -.35, hw: .93, yLow: .3, yBelt: .78, yTop: 1.4, crown: .05 },
    { z: .45, hw: .93, yLow: .3, yBelt: .78, yTop: 1.4, crown: .05 }, { z: .85, hw: .92, yLow: .3, yBelt: .78, yTop: 1.2, crown: .04 }, { z: 1.1, hw: .92, yLow: .3, yBelt: .78, yTop: .99, crown: .03 },
    { z: 1.6, hw: .91, yLow: .32, yBelt: .76, yTop: .93, crown: .03 }, { z: 2.05, hw: .86, yLow: .35, yBelt: .7, yTop: .84, crown: .03 }, { z: 2.28, hw: .76, yLow: .38, yBelt: .6, yTop: .72, crown: .02 }],
    sideWin: [[-.8, -.22], [-.04, .6]], topWin: [[.45, 1.1], [-1.2, -.85]], axle: [1.3, -1.3], track: .8, wr: .362, doorZ: [-.14, .72, -.98], hoodZ: 1.1, trunkZ: -1.35 },
  sport: { keys: [
    { z: -2.2, hw: .82, yLow: .3, yBelt: .6, yTop: .8, crown: .02 }, { z: -2.0, hw: .92, yLow: .27, yBelt: .66, yTop: .92, crown: .03 }, { z: -1.6, hw: .96, yLow: .25, yBelt: .7, yTop: 1.0, crown: .03 },
    { z: -1.0, hw: .97, yLow: .25, yBelt: .72, yTop: 1.2, crown: .04 }, { z: -.3, hw: .97, yLow: .25, yBelt: .72, yTop: 1.3, crown: .05 }, { z: .35, hw: .97, yLow: .25, yBelt: .72, yTop: 1.3, crown: .05 },
    { z: .8, hw: .96, yLow: .25, yBelt: .72, yTop: 1.06, crown: .04 }, { z: 1.1, hw: .96, yLow: .25, yBelt: .72, yTop: .9, crown: .03 }, { z: 1.7, hw: .94, yLow: .27, yBelt: .68, yTop: .82, crown: .03 },
    { z: 2.1, hw: .88, yLow: .29, yBelt: .6, yTop: .7, crown: .02 }, { z: 2.3, hw: .78, yLow: .32, yBelt: .5, yTop: .6, crown: .015 }],
    sideWin: [[-.95, .45]], topWin: [[.35, 1.0], [-1.45, -.5]], axle: [1.35, -1.3], track: .84, wr: .35, doorZ: [.5, -.1], hoodZ: 1.05, trunkZ: -1.6, low: true },
  suv: { keys: [
    { z: -2.3, hw: .88, yLow: .42, yBelt: 1.0, yTop: 1.5, crown: .03 }, { z: -2.2, hw: .93, yLow: .4, yBelt: 1.0, yTop: 1.7, crown: .04 }, { z: -2.0, hw: .95, yLow: .38, yBelt: 1.0, yTop: 1.76, crown: .05 },
    { z: 0, hw: .96, yLow: .38, yBelt: 1.0, yTop: 1.78, crown: .05 }, { z: 1.0, hw: .96, yLow: .38, yBelt: 1.0, yTop: 1.76, crown: .05 }, { z: 1.4, hw: .95, yLow: .38, yBelt: 1.0, yTop: 1.5, crown: .04 },
    { z: 1.7, hw: .95, yLow: .4, yBelt: 1.0, yTop: 1.14, crown: .03 }, { z: 2.1, hw: .92, yLow: .42, yBelt: 1.0, yTop: 1.06, crown: .03 }, { z: 2.4, hw: .84, yLow: .45, yBelt: .9, yTop: .96, crown: .02 }],
    sideWin: [[-2.0, -1.1], [-.9, -.12], [.1, 1.6]], topWin: [[1.0, 1.7], [-2.25, -2.12]], axle: [1.5, -1.4], track: .86, wr: .4, doorZ: [-.03, 1.25, -1.0], hoodZ: 1.7, trunkZ: -2.2, tall: true },
  pickup: { keys: [
    { z: -.62, hw: .93, yLow: .42, yBelt: .98, yTop: 1.3, crown: .03 }, { z: -.55, hw: .95, yLow: .4, yBelt: .98, yTop: 1.6, crown: .04 }, { z: -.4, hw: .95, yLow: .4, yBelt: .98, yTop: 1.65, crown: .05 },
    { z: .5, hw: .95, yLow: .4, yBelt: .98, yTop: 1.65, crown: .05 }, { z: .9, hw: .95, yLow: .4, yBelt: .98, yTop: 1.38, crown: .04 }, { z: 1.2, hw: .95, yLow: .4, yBelt: .98, yTop: 1.08, crown: .03 },
    { z: 1.8, hw: .94, yLow: .42, yBelt: .98, yTop: 1.04, crown: .03 }, { z: 2.35, hw: .9, yLow: .44, yBelt: .9, yTop: .94, crown: .03 }, { z: 2.6, hw: .8, yLow: .46, yBelt: .8, yTop: .8, crown: .02 }],
    sideWin: [[-.4, .05], [.12, .8]], topWin: [[.5, 1.2], [-.62, -.5]], axle: [1.55, -1.45], track: .88, wr: .4, doorZ: [.06, 1.0], hoodZ: 1.2, trunkZ: -.6, pick: true },
};
function interior(C, M, S) {
  const hw = sampleBody(S, 0, 'hw') * .78, yb = sampleBody(S, S.hoodZ - .3, 'yBelt'), yf = sampleBody(S, 0, 'yLow') + .06, zf = S.hoodZ - .25, seat = M.seat, pl = M.plastic;
  C.add(roundBoxG(hw * 2, .05, 2.2, .02), pl, [0, yf + .03, zf - 1.1]);
  C.add(roundBoxG(hw * 1.95, .2, .42, .06), pl, [0, yb - .1, zf - .1]);
  C.add(roundBoxG(.5, .35, .7, .05), pl, [0, yf + .18, zf - 1.0]);
  for (const sx of [-1, 1]) { C.add(roundBoxG(.46, .14, .5, .05), seat, [sx * hw * .5, yf + .32, zf - 1.15]); C.add(roundBoxG(.46, .6, .12, .05), seat, [sx * hw * .5, yf + .66, zf - 1.45], [-.15, 0, 0]); C.add(roundBoxG(.26, .13, .1, .04), seat, [sx * hw * .5, yf + 1.02, zf - 1.5]); }
  if (!S.pick) { const rz = Math.max(zf - 2.2, S.trunkZ + .6); C.add(roundBoxG(hw * 1.8, .14, .5, .05), seat, [0, yf + .32, rz]); C.add(roundBoxG(hw * 1.8, .6, .12, .05), seat, [0, yf + .66, rz - .3], [-.15, 0, 0]); }
  C.add(roundBoxG(.2, .06, .08, .02), pl, [0, yb + .62 * (S.tall ? 1.1 : .55), zf - .2]);                     // rear-view mirror
}
function bodyFromSpec(C, M, o, S) {
  const { paint, glass, chrome, plastic, plateM } = M, headM = o.burnt ? M.plastic : M.headM, tailMat = o.burnt ? M.plastic : M.tailMat, revMat = o.burnt ? M.plastic : M.revMat, L = loftBody(S), keys = S.keys, zf = keys[keys.length - 1].z, zr = keys[0].z;
  C.add(L.paint, paint); if (!o.burnt) { C.add(L.glass, glass); interior(C, M, S); }
  const hwAt = z => sampleBody(S, z, 'hw'), ytAt = z => sampleBody(S, z, 'yTop'), ybAt = z => sampleBody(S, z, 'yBelt'), ylAt = z => sampleBody(S, z, 'yLow');
  // wheel arches: dark opening + painted flare lip
  for (const z of S.axle) for (const s of [-1, 1]) {
    const x = s * hwAt(z), r = S.wr + .085;
    C.add(new THREE.CylinderGeometry(r, r, .03, 22), plastic, [x + s * .004, S.wr, z], [0, 0, Math.PI / 2]);
    C.add(new THREE.TorusGeometry(r + .01, .03, 6, 18, Math.PI), paint, [x + s * .015, S.wr, z], [0, Math.PI / 2, 0]);
  }
  for (const s of [-1, 1]) {
    const hw = hwAt(0);
    // rocker + door shut lines + handles + mirrors
    C.box(plastic, [s * (hwAt(0) * .985), ylAt(0) + .06, (S.axle[0] + S.axle[1]) / 2], [.05, .1, Math.abs(S.axle[0] - S.axle[1]) - .5]);
    for (const dz of S.doorZ) { const yb = ybAt(dz), x = s * hwAt(dz) * .996; C.box(plastic, [x, (yb + ylAt(dz) + .12) / 2, dz], [.012, yb - ylAt(dz) - .14, .014]); }
    const dz = S.doorZ[0]; C.box(chrome, [s * hwAt(dz - .3) * 1.0, ybAt(dz) - .06, dz - .3], [.012, .03, .14]); C.box(chrome, [s * hwAt(dz + .55) * 1.0, ybAt(dz) - .06, dz + .55], [.012, .03, .14]);
    const mz = S.hoodZ - .1; C.add(SPH, paint, [s * (hwAt(mz) + .07), ybAt(mz) + .1, mz], [0, 0, 0], [.07, .06, .1]); C.box(plastic, [s * (hwAt(mz) + .03), ybAt(mz) + .06, mz - .02], [.05, .025, .05]);
    // headlights (swept ellipsoids) + intakes
    const hz = zf - .12, hx = s * hwAt(hz) * .66, hy = ytAt(hz) - .06;
    C.add(SPH, headM, [hx, hy, hz], [0, -s * .35, 0], [.2, .075, .12]); C.add(SPH, chrome, [hx, hy - .1, hz + .02], [0, -s * .3, 0], [.17, .018, .09]);
    C.add(SPH, plastic, [s * hwAt(zf - .2) * .78, ylAt(zf) + .1, zf - .1], [0, 0, 0], [.2, .06, .08]);
    // tail lights
    const tz = zr + .1, tx = s * hwAt(tz) * .78, ty = ytAt(tz) - .06; C.add(SPH, tailMat, [tx, ty, tz], [0, s * .3, 0], [.22, .06, .07]); C.box(revMat, [s * hwAt(tz) * .5, ty - .12, tz - .02], [.1, .05, .04]);
    C.add(new THREE.CylinderGeometry(.045, .045, .22, 14), chrome, [s * hwAt(tz) * .62, ylAt(tz) + .02, zr - .02], [Math.PI / 2, 0, 0]);   // exhaust
  }
  // front/rear bumpers, grille, plates
  C.add(SPH, plastic, [0, ylAt(zf) + .06, zf - .08], [0, 0, 0], [hwAt(zf - .1) * .92, .09, .14]); C.add(SPH, plastic, [0, ylAt(zr) + .06, zr + .08], [0, 0, 0], [hwAt(zr + .1) * .92, .09, .14]);
  C.add(SPH, plastic, [0, ytAt(zf - .1) - .18, zf - .06], [0, 0, 0], [.42, .09, .07]); for (let i = -2; i <= 2; i++) C.box(chrome, [i * .12, ytAt(zf - .1) - .18, zf + .005], [.018, .1, .015]);
  C.box(plateM, [0, ylAt(zr) + .26, zr - .01], [.5, .12, .02]); C.box(plateM, [0, ylAt(zf) + .17, zf + .015], [.5, .11, .02]);
  C.box(plastic, [0, ytAt(S.hoodZ + .4) + .005, S.hoodZ + .4], [.01, .008, .9]); C.box(plastic, [0, ytAt(S.trunkZ + .3) + .02, S.trunkZ + .3], [.01, .008, .6]);     // hood / trunk shut lines
  if (S.low) { C.box(paint, [0, ytAt(zr + .4) + .1, zr + .38], [1.6, .04, .3], [.1, 0, 0]); for (const s of [-1, 1]) C.box(plastic, [s * .6, ytAt(zr + .4) + .02, zr + .38], [.05, .16, .12]); C.add(SPH, plastic, [0, ylAt(zr) + .1, zr + .15], [0, 0, 0], [.8, .05, .12]); }   // spoiler + diffuser
  if (S.tall) { for (const s of [-1, 1]) C.box(chrome, [s * .82, 1.8, -.2], [.03, .03, 2.4]); C.add(new THREE.CylinderGeometry(.5, .5, .2, 20), plastic, [0, .9, zr - .12], [Math.PI / 2, 0, 0]); C.add(new THREE.CylinderGeometry(.22, .22, .22, 14), M.steelRim, [0, .9, zr - .13], [Math.PI / 2, 0, 0]); C.box(chrome, [0, .62, zf - .06], [1.3, .05, .05]); for (const s of [-1, 1]) C.box(chrome, [s * .65, .75, zf - .06], [.05, .3, .05]); }   // roof rails, spare, bull bar
  if (!S.tall && !S.pick) C.add(new THREE.CylinderGeometry(.01, .01, .45, 6), plastic, [.55, 1.45, zr + .7]);
  const zA = Math.min(...S.sideWin.map(w => w[0])), zB = Math.max(...S.sideWin.map(w => w[1]));
  for (const s of [-1, 1]) { C.box(chrome, [s * hwAt((zA + zB) / 2) * .994, ybAt((zA + zB) / 2) + .012, (zA + zB) / 2], [.012, .018, zB - zA + .1]); C.add(new THREE.CylinderGeometry(.03, .03, .02, 10), chrome, [s * hwAt(zr + .7), ybAt(zr + .7) - .1, zr + .7], [0, 0, Math.PI / 2]); }   // belt trim + fuel cap
  for (const x of [-.3, .3]) C.box(plastic, [x, ytAt(S.hoodZ + .02) + .012, S.hoodZ + .04], [.5, .012, .016], [0, x * 1.2, -.25]);   // wipers
  if (S.low) C.add(new THREE.SphereGeometry(1, 12, 8), paint, [0, ytAt(1.5) + .02, 1.5], [0, 0, 0], [.26, .05, .4]);   // hood scoop
}
function buildSedan(C, M, o) { bodyFromSpec(C, M, o, o.sport ? SPECS.sport : SPECS.sedan); }
function buildSuv(C, M, o) { bodyFromSpec(C, M, o, SPECS.suv); }

function buildPickup(C, M) {
  const { paint, chrome, plastic, bedLiner } = M; bodyFromSpec(C, M, {}, SPECS.pickup);
  C.box(bedLiner, [0, .8, -1.55], [1.7, .08, 1.95]);
  [-1, 1].forEach(s => {
    C.box(paint, [s * .93, 1.02, -1.57], [.14, .5, 2.0]); C.box(chrome, [s * .93, 1.28, -1.57], [.16, .03, 2.0]);
    C.add(new THREE.CylinderGeometry(.5, .5, .16, 22, 1, false, 0, Math.PI), paint, [s * .93, .4, -1.45], [0, 0, s * Math.PI / 2], [1, 1, 1]);   // rear wheel-arch housing
    C.add(new THREE.CylinderGeometry(.035, .035, .95, 8), plastic, [s * .78, 1.8, -.7]);
  });
  C.box(paint, [0, 1.0, -.74], [1.7, .52, .1]); C.box(paint, [0, .98, -2.58], [1.7, .5, .08]); C.box(chrome, [0, 1.24, -2.6], [1.7, .03, .08]);
  C.add(new THREE.CylinderGeometry(.035, .035, 1.7, 8), plastic, [0, 2.0, -.75], [0, 0, Math.PI / 2]);
  C.box(plastic, [0, .38, -2.6], [1.9, .16, .12]); C.box(M.tailMat, [-.78, .98, -2.6], [.14, .3, .06]); C.box(M.tailMat, [.78, .98, -2.6], [.14, .3, .06]);
}

function buildJeep(C, M) {
  const { paint, glass, chrome, plastic, headM, tailMat, revMat, rubber, seat } = M;
  C.box(plastic, [0, .42, 0], [1.5, .22, 3.6]);                       // chassis
  C.add(roundBoxG(1.72, .56, 2.3, .1), paint, [0, .8, -.3]);            // tub
  C.box(plastic, [0, 1.09, -.3], [1.62, .04, 2.2]);                    // floor liner
  C.add(roundBoxG(1.5, .46, 1.3, .12), paint, [0, .92, 1.12]);          // hood
  C.add(roundBoxG(1.0, .06, .9, .025), paint, [0, 1.17, 1.2], [-.05, 0, 0]);
  [-1, 1].forEach(s => {
    C.add(roundBoxG(.4, .14, 1.12, .06), paint, [s * .88, 1.02, 1.2]);   // fenders
    C.box(paint, [s * .86, .72, 1.75], [.36, .5, .12]);
    C.add(CYL(.12, .12, .1, 16), headM, [s * .56, 1., 1.66], [Math.PI / 2, 0, 0]);
    C.add(CYL(.15, .15, .05, 16), chrome, [s * .56, 1., 1.64], [Math.PI / 2, 0, 0]);
    C.box(tailMat, [s * .72, .92, -1.46], [.22, .16, .06]); C.box(revMat, [s * .45, .78, -1.47], [.12, .08, .05]);
    C.box(plastic, [s * .95, .5, 0], [.14, .06, 1.9]);                 // side steps
    C.add(roundBoxG(.5, .14, .5, .05), seat, [s * .4, 1.2, -.12]); C.add(roundBoxG(.5, .5, .12, .05), seat, [s * .4, 1.46, -.4], [-.12, 0, 0]);  // seats
    C.box(paint, [s * .95, 1.2, -1.3], [.08, .24, .6]);
    C.box(plastic, [s * 1.0, 1.35, .6], [.08, .14, .2]);               // mirrors
    // windshield posts
    C.box(plastic, [s * .72, 1.4, .5], [.05, .62, .05], [-.38, 0, 0]);
    // roll bar
    C.add(CYL(.035, .035, 1.1, 8), plastic, [s * .8, 1.62, -.95]);
  });
  C.box(plastic, [0, 1.58, .22], [1.5, .05, .05]);                      // windshield top rail
  C.add(PLN(1.4, .6), glass, [0, 1.38, .5], [-.38, 0, 0]);
  C.add(CYL(.035, .035, 1.6, 8), plastic, [0, 2.17, -.95], [0, 0, Math.PI / 2]);
  C.add(CYL(.03, .03, 1.5, 8), plastic, [0, 1.7, -1.35], [0, 0, Math.PI / 2]);
  C.box(plastic, [0, 1.12, 1.67], [1.2, .5, .08]);                      // grille
  for (let i = -2; i <= 2; i++) C.box(chrome, [i * .2, 1.12, 1.715], [.05, .42, .02]);
  C.box(plastic, [0, .55, 1.86], [1.84, .2, .2]);                        // bumper
  C.box(plastic, [0, .55, -1.62], [1.84, .2, .2]);
  C.box(paint, [0, .84, -1.5], [1.72, .5, .08]);                         // tailgate
  C.add(CYL(.4, .4, .22, 20), rubber, [0, .96, -1.76], [Math.PI / 2, 0, 0]);   // spare
  C.add(CYL(.2, .2, .24, 14), M.steelRim, [0, .96, -1.77], [Math.PI / 2, 0, 0]);
  C.add(CYL(.045, .045, 1.0, 8), plastic, [.82, 1.62, .45]);            // snorkel
  C.box(paint, [-.98, 1.2, -.4], [.12, .46, .3]);                        // jerry can
  C.box(plastic, [0, 1.3, 1.45], [.5, .05, .4]);                         // hood vent
}

export const TYPES = {
  sedan: { noArch: true, name: 'SEDAN', maxV: 32, acc: 7.4, brk: 9.5, grip: 11.5, wb: 2.6, wr: .362, ww: .24, steer: .58, axle: [1.3, -1.3], track: .8, style: 'spoke', circles: [[0, 1.35, .95], [0, 0, 1.0], [0, -1.35, .95]], arch: .43, y0: .35, exit: 2.3 },
  jeep: { name: 'JEEP', maxV: 24, acc: 6.2, brk: 9, grip: 10, wb: 2.4, wr: .44, ww: .3, steer: .62, axle: [1.2, -1.15], track: .95, style: 'steel', circles: [[0, 1.2, 1.0], [0, 0, 1.0], [0, -1.2, 1.0]], arch: .5, y0: .44, exit: 2.4 },
  pickup: { name: 'PICKUP', maxV: 27, acc: 6.4, brk: 9, grip: 10.5, wb: 3.1, wr: .4, ww: .28, steer: .54, axle: [1.55, -1.45], track: .88, style: 'steel', circles: [[0, 1.9, .98], [0, .3, 1.0], [0, -1.3, 1.0], [0, -2.1, .98]], arch: .47, y0: .4, exit: 2.4, noArch: true },
  sport: { name: 'SPORT', maxV: 39, acc: 9.2, brk: 11, grip: 13, wb: 2.65, wr: .35, ww: .27, steer: .52, axle: [1.15, -1.5], track: .84, style: 'multi', circles: [[0, 1.35, .95], [0, 0, 1.0], [0, -1.35, .95]], arch: .43, y0: .33, exit: 2.3, noArch: true },
  suv: { name: 'SUV', maxV: 29, acc: 6.8, brk: 9.5, grip: 10.8, wb: 2.9, wr: .4, ww: .28, steer: .55, axle: [1.5, -1.4], track: .86, style: 'steel', circles: [[0, 1.6, 1.0], [0, 0, 1.05], [0, -1.5, 1.0]], arch: .47, y0: .4, exit: 2.5, noArch: true },
};
TYPES.wreck = { ...TYPES.sedan, wreck: true };

export class TyreFX {
  constructor(scene) {
    this.SM = 90; this.p = new Float32Array(this.SM * 3); this.l = new Float32Array(this.SM); this.v = new Float32Array(this.SM * 3); this.i = 0;
    for (let i = 0; i < this.SM; i++) this.p[i * 3 + 1] = -50;
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(this.p, 3)); this.g = g;
    const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), gr = x.createRadialGradient(32, 32, 2, 32, 32, 30);
    gr.addColorStop(0, 'rgba(230,230,230,.9)'); gr.addColorStop(1, 'rgba(230,230,230,0)'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
    const pts = new THREE.Points(g, new THREE.PointsMaterial({ map: new THREE.CanvasTexture(c), size: 1.5, transparent: true, opacity: .55, depthWrite: false, fog: true }));
    pts.frustumCulled = false; scene.add(pts);
    this.NSK = 400; this.sk = new THREE.InstancedMesh(new THREE.PlaneGeometry(.22, .55).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x14110e, transparent: true, opacity: .55, depthWrite: false }), this.NSK);
    this.sk.frustumCulled = false; const z = new THREE.Matrix4().makeScale(0, 0, 0); for (let i = 0; i < this.NSK; i++) this.sk.setMatrixAt(i, z); scene.add(this.sk);
    this.si = 0; this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._p = new THREE.Vector3(); this._s = new THREE.Vector3(1, 1, 1); this._y = new THREE.Vector3(0, 1, 0);
  }
  puff(x, z, vx, vz) { const i = this.i; this.i = (i + 1) % this.SM; this.p[i * 3] = x; this.p[i * 3 + 1] = .25; this.p[i * 3 + 2] = z; this.v[i * 3] = (Math.random() - .5) * .8 + vx * .15; this.v[i * 3 + 1] = .5 + Math.random() * .6; this.v[i * 3 + 2] = (Math.random() - .5) * .8 + vz * .15; this.l[i] = 1; }
  skid(x, z, ang) { this._q.setFromAxisAngle(this._y, ang); this._p.set(x, .03, z); this._m.compose(this._p, this._q, this._s); this.sk.setMatrixAt(this.si, this._m); this.si = (this.si + 1) % this.NSK; this.sk.instanceMatrix.needsUpdate = true; }
  update(dt) {
    for (let i = 0; i < this.SM; i++) if (this.l[i] > 0) { this.l[i] -= dt * .9; this.p[i * 3] += this.v[i * 3] * dt; this.p[i * 3 + 1] += this.v[i * 3 + 1] * dt; this.p[i * 3 + 2] += this.v[i * 3 + 2] * dt; if (this.l[i] <= 0) this.p[i * 3 + 1] = -50; }
    this.g.attributes.position.needsUpdate = true;
  }
}

export class Vehicle {
  constructor(type, scene, env, o = {}) {
    this.type = type; this.P = TYPES[type]; this.wreck = !!this.P.wreck; this.scene = scene;
    this.group = new THREE.Group(); scene.add(this.group);
    this.body = new THREE.Group(); this.body.position.y = this.P.y0; this.group.add(this.body);
    this.inner = new THREE.Group(); this.inner.position.y = -this.P.y0; this.body.add(this.inner);
    this.wheelSpin = []; this.wheelSteer = [];
    const S = shared(env);
    this.tailMat = new THREE.MeshStandardMaterial({ color: 0x7a0b0b, emissive: 0xff1212, emissiveIntensity: .5, roughness: .3 });
    this.revMat = new THREE.MeshStandardMaterial({ color: 0xdddddd, emissive: 0xffffff, emissiveIntensity: 0, roughness: .3 });
    const kind = this.wreck ? 'burnt' : (type === 'jeep' ? 'matte' : 'gloss');
    if (type === 'wreck') this.type = 'sedan';
    const color = this.wreck ? 0x2c2825 : (o.color ?? 0x8e0d14);
    const M = { ...S, paint: paintMat(env, color, kind), tailMat: this.tailMat, revMat: this.revMat };
    const C = new Collector();
    if (type === 'jeep') buildJeep(C, M); else if (type === 'pickup') buildPickup(C, M); else if (type === 'suv') buildSuv(C, M, {}); else buildSedan(C, M, { burnt: this.wreck, sport: type === 'sport' });
    C.build(this.inner);
    if (!this.wreck) { const sp = type === 'jeep' ? null : type === 'sport' ? SPECS.sport : type === 'suv' ? SPECS.suv : type === 'pickup' ? SPECS.pickup : SPECS.sedan;
      const hw = sp ? sampleBody(sp, 0, 'hw') * .78 : .75, yb = sp ? sampleBody(sp, sp.hoodZ - .3, 'yBelt') : 1.3, zf = sp ? sp.hoodZ - .25 : .35;
      const grp = new THREE.Group(); grp.position.set(hw * .5, yb + .08, zf - .62); const tilt = new THREE.Group(); tilt.rotation.x = -.55; grp.add(tilt); const wheel = new THREE.Group(); tilt.add(wheel);
      wheel.add(new THREE.Mesh(new THREE.TorusGeometry(.17, .02, 6, 18), S.plastic)); for (const r of [0, 1.05, 2.1]) { const sk = new THREE.Mesh(new THREE.BoxGeometry(.32, .02, .02), S.plastic); sk.rotation.z = r; wheel.add(sk); }
      this.inner.add(grp); this.steerWheel = wheel; }
    // wheels
    const P = this.P, wg = wheelGeos(P.wr, P.ww, P.style), rimMat = P.style !== 'steel' ? S.rimM : S.steelRim;
    [[-1, P.axle[0]], [1, P.axle[0]], [-1, P.axle[1]], [1, P.axle[1]]].forEach(([s, z]) => {
      if (this.wreck && s === 1 && z > 0) return;
      const st = new THREE.Group(); st.position.set(s * P.track, P.wr, z); this.inner.add(st);
      const sp = new THREE.Group(); st.add(sp);
      const t = new THREE.Mesh(wg.tire, S.rubber); t.castShadow = true; sp.add(t);
      const r = new THREE.Mesh(wg.rim, rimMat); if (s < 0) r.rotation.y = Math.PI; sp.add(r);
      this.wheelSpin.push({ g: sp, rear: z < 0 }); if (z > 0) this.wheelSteer.push(st);
      if (!P.noArch) { const arch = new THREE.Mesh(CYL(P.arch, P.arch, .02, 24), S.plastic); arch.rotation.z = Math.PI / 2; arch.position.set(s * (P.track + .1), P.arch * .9, z); this.inner.add(arch); }
    });
    if (type === 'sport' && MODELS.ferrari) {            // real Blender-quality model (decimated Ferrari 458); front faces -Z in the file
      while (this.inner.children.length) this.inner.remove(this.inner.children[0]);
      this.wheelSpin = []; this.wheelSteer = []; this.steerWheel = null; this.spinSign = -1;
      const car = MODELS.ferrari.scene.clone(true), wrap = new THREE.Group(); wrap.rotation.y = Math.PI; wrap.add(car); this.inner.add(wrap);
      car.traverse(m => { if (m.isMesh) { m.castShadow = true; if (m.material && m.material.name === 'Body_Color') { m.material = m.material.clone(); m.material.color.set(o.color ?? 0xe0a21a); m.material.envMapIntensity = 1.2; } } });
      wrap.updateMatrixWorld(true); const bb = new THREE.Box3().setFromObject(wrap); wrap.position.y = -bb.min.y;
      const nodes = ['wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr'].map(n => car.getObjectByName(n)); nodes.forEach((n, i) => { if (!n) return; n.rotation.order = 'YXZ'; this.wheelSpin.push({ g: n, rear: i >= 2 }); if (i < 2) this.wheelSteer.push(n); });
    }
    if (this.wreck) { this.body.rotation.z = .07; this.body.position.y = P.y0 - .08; }
    this.group.position.set(o.x ?? 0, 0, o.z ?? 0); this.group.rotation.y = o.rot ?? 0;
    this.vx = 0; this.vz = 0; this.yawR = 0; this.steer = 0; this.wheelRot = 0; this.pitch = 0; this.pitchV = 0; this.roll = 0; this.rollV = 0; this.lastVl = 0; this.skD = 0;
    this.speed = 0; this.vl = 0; this.skidAmt = 0; this.sliding = false; this.impact = 0; this.occupied = false;
    this.initial = { x: o.x ?? 0, z: o.z ?? 0, rot: o.rot ?? 0 };
  }
  reset() { this.group.position.set(this.initial.x, 0, this.initial.z); this.group.rotation.y = this.initial.rot; this.vx = this.vz = this.yawR = this.steer = 0; this.occupied = false; this.speed = 0; this.vl = 0; }
  get x() { return this.group.position.x; } get z() { return this.group.position.z; } get heading() { return this.group.rotation.y; }
  circles() {
    const h = this.heading, s = Math.sin(h), c = Math.cos(h), out = [];
    for (const [ox, oz, r] of this.P.circles) out.push([this.x + s * oz + c * ox, this.z + c * oz - s * ox, r]);
    return out;
  }
  /** Follow a car driven by another player (state arrives ~15x/s): smooth toward it and animate wheels. */
  applyRemote(s, dt) {
    const age = Math.min(.25, (performance.now() - s.t) / 1000), k = Math.min(1, 12 * dt);
    const tx = s.x + s.vx * age, tz = s.z + s.vz * age; let dh = s.h - this.heading; dh = Math.atan2(Math.sin(dh), Math.cos(dh));
    if (Math.hypot(tx - this.x, tz - this.z) > 6) { this.group.position.x = tx; this.group.position.z = tz; this.group.rotation.y = s.h; }
    else { this.group.position.x += (tx - this.x) * k; this.group.position.z += (tz - this.z) * k; this.group.rotation.y += dh * k; }
    this.vx = s.vx; this.vz = s.vz; this.vl = s.vl; this.speed = Math.hypot(s.vx, s.vz); this.steer += (s.st - this.steer) * Math.min(1, 8 * dt); this.impact = 0; this.sliding = false;
    this.wheelRot += s.vl * dt / this.P.wr;
    this.wheelSpin.forEach(w => { w.g.rotation.x = this.wheelRot * (this.spinSign || 1); });
    this.wheelSteer.forEach(q => q.rotation.y = this.steer * (this.spinSign || 1)); if (this.steerWheel) this.steerWheel.rotation.z = -this.steer * 2.6;
  }
  update(dt, inp, colliders, others, fx) {
    if (this.wreck) return;
    const P = this.P, thr = inp.thr, st = inp.st, hb = inp.hb;
    let h = this.heading; const fx_ = Math.sin(h), fz = Math.cos(h), lx = Math.cos(h), lz = -Math.sin(h);
    let vl = this.vx * fx_ + this.vz * fz, vt = this.vx * lx + this.vz * lz;
    let a = 0; const av = Math.abs(vl);
    if (thr > .05) { if (vl > -.6) a = thr * (av < P.maxV ? P.acc * Math.pow(1 - Math.max(vl, 0) / P.maxV, .75) : 0); else a = P.brk * thr; }
    else if (thr < -.05) { if (vl > .6) a = P.brk * 1.03 * thr; else a = thr * 3.4 * (1 - Math.min(av / 8, 1)); }
    else a -= Math.sign(vl) * 1.1;
    a -= Math.sign(vl) * (.2 + .0011 * vl * vl); vl += a * dt;
    if (hb) { const d = Math.min(Math.abs(vl), 6 * dt); vl -= Math.sign(vl) * d; }
    if (thr < .05 && thr > -.05 && Math.abs(vl) < .25 && !hb) vl = 0;
    const maxSt = clamp(P.steer - Math.abs(vl) * .013, .12, P.steer);
    this.steer += (-st * maxSt - this.steer) * Math.min(1, 7 * dt);
    const yawT = vl / P.wb * Math.tan(this.steer) * (hb ? 1.35 : 1);
    this.yawR += (yawT - this.yawR) * Math.min(1, 9 * dt);
    const grip = hb ? 3.2 : P.grip; let skidAmt = 0, dvt = grip * dt;
    if (Math.abs(vt) <= dvt) { vl = Math.sign(vl || 1) * Math.sqrt(vl * vl + vt * vt) * (vl === 0 ? 0 : 1); vt = 0; } else { skidAmt = Math.abs(vt); vt -= Math.sign(vt) * dvt; }
    const spin = thr > .9 && vl < 5 && vl > -1;
    this.vx = fx_ * vl + lx * vt; this.vz = fz * vl + lz * vt;
    h += this.yawR * dt; this.group.rotation.y = h;
    let px = this.x + this.vx * dt, pz = this.z + this.vz * dt;
    // ---- collisions: wall boxes + other vehicles (3-4 circles per car) ----
    let hit = 0; const sh = Math.sin(h), ch = Math.cos(h);
    for (let pass = 0; pass < 2; pass++) for (const [ox, oz, r] of P.circles) {
      const wx = px + sh * oz + ch * ox, wz = pz + ch * oz - sh * ox;
      const o = resolveCircle(wx, wz, r, colliders, 0);
      if (o.hit) { px += o.x - wx; pz += o.z - wz; const vn = this.vx * o.nx + this.vz * o.nz; if (vn < 0) { hit = Math.max(hit, -vn); this.vx -= 1.3 * vn * o.nx; this.vz -= 1.3 * vn * o.nz; this.vx *= .85; this.vz *= .85; this.yawR *= .8; } }
      for (const v of others) {
        if (v === this) continue;
        for (const [qx, qz, qr] of v.circles()) {
          const wx2 = px + sh * oz + ch * ox, wz2 = pz + ch * oz - sh * ox, dx = wx2 - qx, dz = wz2 - qz, d = Math.hypot(dx, dz), m = r + qr;
          if (d < m && d > 1e-4) { const nx = dx / d, nz = dz / d; px += nx * (m - d); pz += nz * (m - d); const vn = this.vx * nx + this.vz * nz; if (vn < 0) { hit = Math.max(hit, -vn); this.vx -= 1.2 * vn * nx; this.vz -= 1.2 * vn * nz; this.vx *= .85; this.vz *= .85; } }
        }
      }
    }
    if (Math.abs(px) > 68) { px = clamp(px, -68, 68); this.vx *= -.2; } if (Math.abs(pz) > 68) { pz = clamp(pz, -68, 68); this.vz *= -.2; }
    this.impact = hit; this.group.position.x = px; this.group.position.z = pz;
    this.speed = Math.hypot(this.vx, this.vz); this.vl = vl; this.skidAmt = skidAmt;
    // ---- suspension ----
    const aLong = (vl - this.lastVl) / Math.max(dt, 1e-3), aLat = this.yawR * vl; this.lastVl = vl;
    const pT = clamp(-aLong * .0075, -.07, .07), rT = clamp(aLat * .0065, -.09, .09);
    this.pitchV += (60 * (pT - this.pitch) - 9 * this.pitchV) * dt; this.pitch += this.pitchV * dt;
    this.rollV += (60 * (rT - this.roll) - 9 * this.rollV) * dt; this.roll += this.rollV * dt;
    this.body.rotation.x = this.pitch; this.body.rotation.z = this.roll;
    // ---- wheels / lights ----
    this.wheelRot += vl * dt / P.wr;
    this.wheelSpin.forEach(w => { w.g.rotation.x = (hb && w.rear) ? w.g.rotation.x : this.wheelRot * (this.spinSign || 1); });
    this.wheelSteer.forEach(s => s.rotation.y = this.steer * (this.spinSign || 1)); if (this.steerWheel) this.steerWheel.rotation.z = -this.steer * 2.6;
    const braking = (thr < -.05 && vl > .6) || hb;
    this.tailMat.emissiveIntensity += ((braking ? 3 : .5) - this.tailMat.emissiveIntensity) * Math.min(1, 20 * dt);
    this.revMat.emissiveIntensity = (thr < -.05 && vl < -.3) ? 2 : 0;
    if (fx && thr > .7 && this.speed < 14 && Math.random() < .3) { const rz = P.axle[1] - 1.1; fx.puff(px + sh * rz - ch * .5, pz + ch * rz + sh * .5, this.vx * .2, this.vz * .2); }
    // ---- smoke + skid marks ----
    this.sliding = skidAmt > 2.4 || (hb && Math.abs(vl) > 4) || spin;
    if (this.sliding && fx) {
      this.skD += this.speed * dt;
      [-1, 1].forEach(s => {
        const rz = P.axle[1];
        const x = px + sh * rz + ch * s * P.track, z = pz + ch * rz - sh * s * P.track;
        if (Math.random() < .7) fx.puff(x, z, this.vx, this.vz);
        if (this.skD > .35 && this.speed > 1.5) fx.skid(x, z, Math.atan2(this.vx, this.vz));
      });
      if (this.skD > .35) this.skD = 0;
    }
  }
}
