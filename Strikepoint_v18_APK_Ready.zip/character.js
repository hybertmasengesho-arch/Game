// The player's operator: your skinned FBX character + the IK walk cycle from walking-avatar.html,
// extended with a two-handed rifle hold (arm IK) that follows the camera pitch.
import * as THREE from 'three';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { bake, seg, mergeColored } from './utils.js';

export const stride = s => s <= 2.2 ? .75 + .38 * s : Math.min(3.2, 1.586 + (s - 2.2) * .62);
const BX = new THREE.BoxGeometry(1, 1, 1);

/** Procedural AR-7 used in the 3rd-person hand and as the first-person viewmodel. Origin = pistol grip, muzzle toward +Z. */
export function buildRifleGeo() {
  const U = [], g = (c, p, s, r) => U.push(bake(BX, c, p, r || [0, 0, 0], s));
  g(0x23282a, [0, .07, .16], [.06, .1, .34]); g(0x30363a, [0, .08, .45], [.07, .08, .3]);        // receiver + handguard
  g(0x1c2022, [0, .05, -.14], [.05, .1, .26]); g(0x1c2022, [0, .01, -.28], [.05, .13, .05]);      // stock + buttpad
  g(0x1c2022, [0, -.06, .02], [.04, .13, .05], [.32, 0, 0]);                                       // pistol grip
  g(0x15181a, [0, -.05, .26], [.045, .17, .08], [-.2, 0, 0]);                                      // magazine
  U.push(seg([0, .075, .6], [0, .075, .92], .014, .014, 0x15181a, 8)); g(0x0e0f10, [0, .075, .95], [.032, .032, .07]);
  g(0x101214, [0, .15, .2], [.05, .05, .16]); g(0x2d4a5a, [0, .15, .29], [.04, .035, .012]);       // optic + lens
  g(0x101214, [0, .125, .52], [.012, .05, .012]);                                                  // front sight
  return mergeColored(U);
}

function lowPolyFix(obj) {
  obj.traverse(o => {
    if (!o.isMesh) return;
    if (/teeth/i.test(o.name)) { o.visible = false; return; }     // never visible at gameplay distance (saves ~7k skinned tris)
    o.castShadow = true; o.frustumCulled = false;
    // FBX meshes arrive un-indexed (3 verts per triangle); welding cuts skinning cost ~3x on phones.
    try { const g = mergeVertices(o.geometry, 1e-4); if (g.attributes.position.count < o.geometry.attributes.position.count) { o.geometry.dispose(); o.geometry = g; } } catch (e) { }
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    const out = mats.map(m => {
      if (m.map) { m.map.colorSpace = THREE.SRGBColorSpace; m.map.anisotropy = 4; }
      const n = new THREE.MeshStandardMaterial({ map: m.map || null, color: m.map ? 0xffffff : m.color, roughness: .78, metalness: 0, transparent: m.transparent, opacity: m.opacity, alphaTest: m.alphaTest });
      n.name = m.name; return n;
    });
    o.material = Array.isArray(o.material) ? out : out[0];
  });
}

function makePose(obj, M) {
  obj.updateMatrixWorld(true);
  const V = (x, y, z) => new THREE.Vector3(x, y, z), X = V(1, 0, 0), Y = V(0, 1, 0);
  const rq = (ax, a) => new THREE.Quaternion().setFromAxisAngle(ax, a);
  const mq = b => { const q = new THREE.Quaternion(), ch = []; for (let n = b; n && n !== obj; n = n.parent) ch.unshift(n); ch.forEach(c => q.multiply(c.quaternion)); return q; };
  const names = ['LeftUpLeg', 'LeftLeg', 'LeftFoot', 'LeftToeBase', 'RightUpLeg', 'RightLeg', 'RightFoot', 'RightToeBase', 'LeftArm', 'LeftForeArm', 'LeftHand', 'RightArm', 'RightForeArm', 'RightHand', 'Hips', 'Spine1', 'Spine2', 'Head'];
  const bm = {}; obj.traverse(o => { if (o.isSkinnedMesh) o.skeleton.bones.forEach(x => { bm[x.name] = x; }); });
  const b = {}, rest = {}; names.forEach(n => { const x = bm[n] || obj.getObjectByName(n); if (x) { b[n] = x; rest[n] = mq(x); } });
  const tmp = V(0, 0, 0), wp = n => { b[n].getWorldPosition(tmp); return tmp.clone(); };
  const set = (n, D) => { if (!b[n]) return; b[n].quaternion.copy(mq(b[n].parent).invert().multiply(D.clone().multiply(rest[n]))); };
  const kf = (a, x) => { for (let i = 1; i < a.length; i++) if (x <= a[i][0]) { const u = (x - a[i - 1][0]) / (a[i][0] - a[i - 1][0]), s = u * u * (3 - 2 * u); return a[i - 1][1] + (a[i][1] - a[i - 1][1]) * s; } return a[a.length - 1][1]; };
  const sm01 = x => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
  const T = Math.PI * 2;
  const hasLegs = b.LeftUpLeg && b.LeftLeg && b.LeftFoot && b.RightUpLeg && b.RightLeg && b.RightFoot;
  const RG = {};
  if (hasLegs) ['Left', 'Right'].forEach(s => { const h = wp(s + 'UpLeg'), k = wp(s + 'Leg'), a = wp(s + 'Foot'); const l1 = h.distanceTo(k), l2 = k.distanceTo(a); RG[s] = { h, k, a, l1, l2, t0: k.clone().sub(h).normalize(), s0: a.clone().sub(k).normalize() }; });
  const hipRestY = hasLegs ? (RG.Left.h.y + RG.Right.h.y) / 2 : 1, ankY = hasLegs ? (RG.Left.a.y + RG.Right.a.y) / 2 : .1, LMAX = hasLegs ? RG.Left.l1 + RG.Left.l2 : 1;
  // arm rest geometry
  const hasArms = b.LeftArm && b.LeftForeArm && b.LeftHand && b.RightArm && b.RightForeArm && b.RightHand;
  const AG = {}; if (hasArms) ['Left', 'Right'].forEach(s => { const sh = wp(s + 'Arm'), el = wp(s + 'ForeArm'), wr = wp(s + 'Hand'); AG[s] = { sh, l1: sh.distanceTo(el), l2: el.distanceTo(wr), t0: el.clone().sub(sh).normalize(), s0: wr.clone().sub(el).normalize() }; });
  const HEEL = [-ankY, -.07], BALL = [-ankY, .105];
  const rot = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
  const footOff = a => { const h = rot(HEEL, a), bl = rot(BALL, a), y = -Math.min(h[0], bl[0]), piv = a < 0 ? [HEEL, h] : [BALL, bl]; return [y, piv[0][1] - piv[1][1]]; };
  const FOOT = [[0, -.24], [.09, 0], [.38, 0], [.6, .5], [.74, .12], [.9, -.18], [1, -.24]];
  let S = .6; const ZC = -.04, FX = .72, out = V(0, 0, 0); let lastT = null, spS = 0; const lat = { Left: { dc: 1.3 }, Right: { dc: 1.3 } };
  const pole = V(0, 0, 1);
  function ik(H, A, l1, l2, res, pl) {
    const d = A.clone().sub(H); let D = d.length(); const n = d.clone().divideScalar(D || 1), Dcl = Math.max(Math.abs(l1 - l2) + 1e-3, Math.min((l1 + l2) * .9995, D));
    const a = (l1 * l1 - l2 * l2 + Dcl * Dcl) / (2 * Dcl), hh = Math.sqrt(Math.max(l1 * l1 - a * a, 0));
    const p = (pl || pole).clone().sub(n.clone().multiplyScalar(n.dot(pl || pole))); if (p.lengthSq() < 1e-6) p.set(1, 0, 0); p.normalize();
    const K = H.clone().add(n.clone().multiplyScalar(a)).add(p.multiplyScalar(hh)), Ac = H.clone().add(n.clone().multiplyScalar(Dcl));
    res.t1 = K.clone().sub(H).normalize(); res.s1 = Ac.clone().sub(K).normalize();
  }
  const smin = (a, c, k) => { const h = Math.max(k - Math.abs(a - c), 0) / k; return Math.min(a, c) - h * h * k * .25; };
  const ar = { t1: null, s1: null }, tgtR = V(0, 0, 0), tgtL = V(0, 0, 0), pv = V(0, 0, 0), poleR = V(-.55, -1, -.35).normalize(), poleL = V(.6, -1, -.2).normalize();
  const rifleM = new THREE.Matrix4(), qa = new THREE.Quaternion(), qb = new THREE.Euler();

  // ph: gait phase, a: walk blend 0..1, time, sp: speed (m/s, anim-capped), aim: 0 low-ready .. 1 shouldered, pitch: aim pitch (rad), rifle: Group in M space
  return (ph, a, time, sp, aim, pitch, rifle, mv = {}) => {
    const reload = mv.reload ?? -1, kick = mv.kick || 0, flinch = mv.flinch || 0, crouch = mv.crouch || 0, run = mv.run || 0, rel = mv.rel || 0, air = mv.air || 0, sprint = mv.sprint || 0;
    const dt = lastT === null ? 0 : Math.max(0, Math.min(.1, time - lastT)); lastT = time;
    spS += (sp - spS) * Math.min(1, 8 * dt); if (dt === 0) spS = sp;
    S = .6 - .22 * run; const k = a * Math.min(1.3, .55 + .45 * sp / 1.4), Dcur = stride(spS);
    const lean = .05 + .07 * Math.min(1, sp / 2.2) * a + (.2 + .1 * sprint) * run * a;
    set('Hips', rq(Y, -.09 * k * Math.cos(T * ph)));
    set('Spine1', rq(Y, .12 * k * Math.cos(T * ph) * (1 - aim * .7)).multiply(rq(X, lean * a + .03 + .02 * Math.sin(time * 2) + .22 * crouch - .05 * kick - .12 * flinch).premultiply(rq(Y, .07 * flinch))));
    set('Head', rq(Y, .35 * Math.sin(time * .6) * (1 - a) * (1 - aim)).multiply(rq(X, -pitch * .45 * aim - lean * 1.1 * a)));
    const lift = (.05 + .03 * Math.min(spS, 1.8)) * (1 - run) + .22 * run, tg = {};
    ['Left', 'Right'].forEach(s => {
      const off = s === 'Left' ? 0 : .5, L = lat[s], f = (((ph + off) % 1) + 1) % 1;
      if (L.prev !== undefined && f < L.prev - .5) L.dc = Dcur; if (L.prev === undefined) L.dc = Dcur; L.prev = f;
      const dc = L.dc, zf = ZC + .3 * dc; let zr, ly = 0;
      if (f < S) zr = zf - dc * f; else { const tau = (f - S) / (1 - S), zb = zf - dc * S, z1 = ZC + .3 * Dcur, m = -dc * (1 - S), t2 = tau * tau, t3 = t2 * tau; zr = (2 * t3 - 3 * t2 + 1) * zb + (t3 - 2 * t2 + tau) * m + (-2 * t3 + 3 * t2) * z1 + (t3 - t2) * m; ly = lift * Math.sin(Math.PI * tau); }
      const pit = kf(FOOT, f) * Math.min(1, k / .8 + .2), fo = footOff(pit), toe = f < S ? Math.min(pit, 0) : Math.min(pit, 0) + Math.max(pit, 0) * sm01((f - S) / (1 - S) / .35);
      tg[s] = { zr, ly, pit, fo, toe, f };
    });
    const aa = Math.max(0, Math.min(1, Math.max(a, crouch))), sway = .018 * Math.sin(T * ph) * aa, tgt = {};
    if (hasLegs) {
      let hy = 1e9;
      ['Left', 'Right'].forEach(s => {
        const g = tg[s], R = RG[s], sgn = s === 'Left' ? 1 : -1, gx = sgn * Math.abs(R.a.x) * FX, gy = g.fo[0] + g.ly, gz = g.zr + g.fo[1];
        const A = V(R.a.x + (gx - R.a.x) * aa, R.a.y + (gy - R.a.y) * aa, R.a.z + (gz - R.a.z) * aa); tgt[s] = A;
        const dx = A.x - (R.h.x + sway), dz = A.z - R.h.z, r = LMAX * .985, c = A.y + Math.sqrt(Math.max(r * r - dx * dx - dz * dz, .25));
        hy = smin(hy > 1e8 ? c : hy, c, .02);
      });
      hy = smin(hy, 1.003 - .012 * Math.cos(T * 2 * ph) - .06 * run * (.5 + .5 * Math.cos(T * 2 * ph + 1)), .02); hy = hipRestY + (hy - hipRestY) * aa - .46 * crouch;
      M.position.y = hy - hipRestY; M.position.x = sway;
    }
    obj.updateMatrixWorld(true);
    if (hasLegs) ['Left', 'Right'].forEach(s => {
      const R = RG[s], g = tg[s], A = tgt[s].clone().sub(V(M.position.x, M.position.y, 0)), H = wp(s + 'UpLeg').clone(); M.worldToLocal(H);
      ik(H, A, R.l1, R.l2, out); set(s + 'UpLeg', new THREE.Quaternion().setFromUnitVectors(R.t0, out.t1)); set(s + 'Leg', new THREE.Quaternion().setFromUnitVectors(R.s0, out.s1));
      set(s + 'Foot', rq(X, g.pit * aa)); set(s + 'ToeBase', rq(X, g.toe * aa));
    });
    // ---- rifle pose: raise from low-ready to shoulder, pitch with the camera ----
    const lowP = -.38 - .45 * sprint * (1 - aim) + Math.sin(T * ph * 2) * (.015 + .03 * run) * a, pr = lowP + (Math.max(-1.1, Math.min(1.1, pitch)) - lowP) * aim;
    const px = -.13 + (-.1 - (-.13)) * aim, py = 1.2 - .06 * sprint * (1 - aim) + (1.46 - 1.2) * aim + Math.sin(T * ph * 2) * (.008 + .02 * run) * a, pz = .24 + (.2 - .24) * aim - .05 * sprint * (1 - aim);
    const rbmp = reload >= 0 ? Math.sin(Math.PI * Math.min(1, reload)) : 0;
    rifle.position.set(px + Math.sin(time * .9) * .004 * (1 - a), py + Math.sin(time * 1.7) * .006 * (1 - a) - .16 * rbmp, pz - .06 * kick + .06 * rbmp); rifle.rotation.set(-pr - .06 * kick + .35 * rbmp, 0, .4 * rbmp); rifle.updateMatrix(); rifleM.copy(rifle.matrix);
    if (hasArms) {
      obj.updateMatrixWorld(true);
      const pos = (sx, sy, sz) => V(sx, sy, sz).applyMatrix4(rifleM);
      tgtR.copy(pos(0, -.015, .04)); tgtL.copy(pos(.005, -.015 - .24 * rbmp, .5 - .26 * rbmp));
      [['Left', tgtL, poleL, 'L'], ['Right', tgtR, poleR, 'R']].forEach(([s, T_, pl]) => {
        const G = AG[s], H = wp(s + 'Arm').clone(); M.worldToLocal(H);
        ik(H, T_, G.l1, G.l2, ar, pl);
        set(s + 'Arm', new THREE.Quaternion().setFromUnitVectors(G.t0, ar.t1));
        const Df = new THREE.Quaternion().setFromUnitVectors(G.s0, ar.s1); set(s + 'ForeArm', Df); set(s + 'Hand', Df);
      });
    }
    return 0;
  };
}

/** Loads the FBX and returns {root, rifle, update(...)} */
export async function loadOperator(onProgress) {
  const loader = new FBXLoader();
  const obj = await loader.loadAsync('assets/character.fbx', e => { if (onProgress && e.total) onProgress(e.loaded / e.total); });
  lowPolyFix(obj);
  const root = new THREE.Group(), M = new THREE.Group(); root.add(M); M.add(obj);
  const rifle = new THREE.Group(); rifle.matrixAutoUpdate = true; M.add(rifle);
  const rm = new THREE.Mesh(buildRifleGeo(), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .6, metalness: .4 })); rm.castShadow = true; rifle.add(rm);
  const flash = new THREE.Mesh(new THREE.PlaneGeometry(.3, .3), new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  flash.position.set(0, .075, 1.0); flash.visible = false; rifle.add(flash);
  const pose = makePose(obj, M);
  pose(0, 0, 0, 1.4, 0, 0, rifle);
  const hat = obj.getObjectByName('hat'); if (hat) hat.visible = true;
  return { root, M, obj, rifle, flash, pose };
}
