// Tiny WebAudio helpers: engine synth (ported from the avatar demo) + gunshots.
let echoIn = null, au = null, eng = null, rpm = 1000, noiseBuf = null;
export const sfx = { on: true };
export function initAudio() {
  if (au) { if (au.state === 'suspended') au.resume(); return; }
  try {
    au = new (window.AudioContext || window.webkitAudioContext)();
    const o1 = au.createOscillator(), o2 = au.createOscillator(), o3 = au.createOscillator();
    o1.type = 'sawtooth'; o2.type = 'square'; o3.type = 'sawtooth';
    const lp = au.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 500; lp.Q.value = 1.5;
    const g = au.createGain(); g.gain.value = 0; const g2 = au.createGain(), g3 = au.createGain(); g2.gain.value = .35; g3.gain.value = .5;
    o1.connect(lp); o2.connect(g2); g2.connect(lp); o3.connect(g3); g3.connect(lp); lp.connect(g); g.connect(au.destination);
    o1.start(); o2.start(); o3.start();
    noiseBuf = au.createBuffer(1, au.sampleRate, au.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const ns = au.createBufferSource(); ns.buffer = noiseBuf; ns.loop = true;
    const bp = au.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 1.4;
    const ng = au.createGain(); ng.gain.value = 0; ns.connect(bp); bp.connect(ng); ng.connect(au.destination); ns.start();
    eng = { o1, o2, o3, lp, g, ng };
    const dl = au.createDelay(1); dl.delayTime.value = .21; const fb = au.createGain(); fb.gain.value = .3; const lp2 = au.createBiquadFilter(); lp2.type = 'lowpass'; lp2.frequency.value = 1000;
    echoIn = au.createGain(); echoIn.gain.value = .35; echoIn.connect(dl); dl.connect(lp2); lp2.connect(fb); fb.connect(dl); lp2.connect(au.destination);
    const ws = au.createBufferSource(); ws.buffer = noiseBuf; ws.loop = true; const wl = au.createBiquadFilter(); wl.type = 'lowpass'; wl.frequency.value = 420; const wg = au.createGain(); wg.gain.value = .03;
    const lfo = au.createOscillator(); lfo.frequency.value = .13; const lg = au.createGain(); lg.gain.value = .018; lfo.connect(lg); lg.connect(wg.gain); ws.connect(wl); wl.connect(wg); wg.connect(au.destination); ws.start(); lfo.start();
  } catch (e) { au = null; eng = null; }
}
export function engineUpdate(thr, speed, skidAmt, on) {
  if (!eng) return; const t = au.currentTime;
  const gears = [0, 9, 16, 23, 30, 42]; let gi = 0; while (gi < 4 && speed > gears[gi + 1]) gi++;
  const frac = Math.min(1, (speed - gears[gi]) / (gears[gi + 1] - gears[gi]));
  const target = 1000 + frac * (gi === 0 ? 3600 : 3200) + Math.max(0, thr) * 500;
  rpm += (target - rpm) * .18; const f = rpm / 30;
  eng.o1.frequency.setTargetAtTime(f, t, .03); eng.o2.frequency.setTargetAtTime(f * .5, t, .03); eng.o3.frequency.setTargetAtTime(f * 2, t, .03);
  eng.lp.frequency.setTargetAtTime(260 + rpm * .22 + Math.max(0, thr) * 300, t, .05);
  eng.g.gain.setTargetAtTime(on && sfx.on ? (.05 + .05 * Math.max(0, thr) + rpm / 150000) : 0, t, .06);
  eng.ng.gain.setTargetAtTime(on && sfx.on ? Math.min(.12, skidAmt * .03) : 0, t, .05);
}
/** Short noise burst. vol 0..1, tone = filter centre in Hz (lower = heavier). */
export function shot(vol = .3, tone = 1800, len = .09) {
  if (!au || !sfx.on || !noiseBuf) return;
  const t = au.currentTime, s = au.createBufferSource(); s.buffer = noiseBuf;
  s.playbackRate.value = .8 + Math.random() * .4;
  const f = au.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(tone, t); f.frequency.exponentialRampToValueAtTime(220, t + len);
  const g = au.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + len);
  s.connect(f); f.connect(g); g.connect(au.destination); if (echoIn && vol > .08) g.connect(echoIn); s.start(t, Math.random() * .5, len + .02);
}
export function thud(vol = .3) { shot(vol, 500, .18); }

export function footstep(vol = .04) { shot(vol, 700, .05); }

export function sting(kind) {
  if (!au || !sfx.on) return; const t = au.currentTime, seq = kind === 'spot' ? [[520, 0], [780, .11], [520, .22]] : [[660, 0], [520, .18], [392, .36]];
  for (const [f, d] of seq) { const o = au.createOscillator(), g = au.createGain(); o.type = kind === 'spot' ? 'square' : 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(0, t + d); g.gain.linearRampToValueAtTime(kind === 'spot' ? .09 : .07, t + d + .01); g.gain.exponentialRampToValueAtTime(.001, t + d + (kind === 'spot' ? .1 : .3)); o.connect(g); g.connect(au.destination); o.start(t + d); o.stop(t + d + .35); }
}
